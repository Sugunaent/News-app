from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from postgrest.exceptions import APIError

from app.core.db_utils import extract_single_record
from app.core.exceptions import AuthorizationError, NotFoundError
from app.dependencies.auth import AuthContext, get_current_user
from app.db.supabase import supabase_admin
from app.schemas.superadmin_interactive import (
    SuperadminOpinionCreate,
    SuperadminOpinionOptionCreate,
    SuperadminOpinionOptionReorder,
    SuperadminOpinionOptionResponse,
    SuperadminOpinionOptionUpdate,
    SuperadminOpinionReorder,
    SuperadminOpinionResponse,
    SuperadminOpinionUpdate,
    SuperadminQuizCorrectAnswerUpdate,
    SuperadminQuizCreate,
    SuperadminQuizDetailResponse,
    SuperadminQuizListItem,
    SuperadminQuizOptionCreate,
    SuperadminQuizOptionReorder,
    SuperadminQuizOptionResponse,
    SuperadminQuizOptionUpdate,
    SuperadminQuizQuestionCreate,
    SuperadminQuizQuestionReorder,
    SuperadminQuizQuestionResponse,
    SuperadminQuizQuestionUpdate,
    SuperadminQuizUpdate,
)
from app.services.audit import record_audit


router = APIRouter(
    prefix="/api/v1/superadmin",
    tags=["Superadmin Interactive Content"],
)


# ============================================================
# AUTHORIZATION
# ============================================================


def _require_superadmin(
    context: AuthContext,
) -> None:
    role = getattr(
        context.user,
        "role",
        None,
    )

    if role != "SUPERADMIN":
        raise AuthorizationError(
            "Superadmin access required"
        )


# ============================================================
# AUDIT
# ============================================================


def _audit(
    auth: AuthContext,
    *,
    action: str,
    entity_type: str,
    entity_id: UUID | None = None,
    metadata: dict | None = None,
) -> None:
    record_audit(
        actor_user_id=UUID(str(auth.user.id)),
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        metadata=metadata or {},
        client=auth.client,
    )


# ============================================================
# HELPERS
# ============================================================


def _article_exists(
    client,
    article_id: UUID,
) -> None:
    result = (
        client.table("articles")
        .select("id")
        .eq("id", str(article_id))
        .maybe_single()
        .execute()
    )

    if not result or not result.data:
        raise NotFoundError(
            "Article not found"
        )


def _get_quiz(
    client,
    quiz_id: UUID,
):
    result = (
        client.table("quizzes")
        .select(
            "id, article_id, title, created_at, updated_at"
        )
        .eq("id", str(quiz_id))
        .maybe_single()
        .execute()
    )

    if not result or not result.data:
        raise NotFoundError(
            "Quiz not found"
        )

    return result.data


def _get_quiz_question(
    client,
    quiz_id: UUID,
    question_id: UUID,
):
    result = (
        client.table("quiz_questions")
        .select(
            "id, quiz_id, display_order, "
            "question_text, created_at, updated_at"
        )
        .eq("id", str(question_id))
        .eq("quiz_id", str(quiz_id))
        .maybe_single()
        .execute()
    )

    if not result or not result.data:
        raise NotFoundError(
            "Quiz question not found"
        )

    return result.data


def _get_quiz_option(
    client,
    question_id: UUID,
    option_id: UUID,
):
    result = (
        client.table("quiz_options")
        .select(
            "id, question_id, display_order, "
            "is_correct, option_text, explanation, created_at, updated_at"
        )
        .eq("id", str(option_id))
        .eq("question_id", str(question_id))
        .maybe_single()
        .execute()
    )

    if not result or not result.data:
        raise NotFoundError(
            "Quiz option not found"
        )

    return result.data


def _get_opinion(
    client,
    opinion_id: UUID,
):
    result = (
        client.table("opinion_questions")
        .select(
            "id, article_id, display_order, "
            "allow_custom_response, question_text, created_at, updated_at"
        )
        .eq("id", str(opinion_id))
        .maybe_single()
        .execute()
    )

    if not result or not result.data:
        raise NotFoundError(
            "Opinion question not found"
        )

    return result.data


def _get_opinion_option(
    client,
    question_id: UUID,
    option_id: UUID,
):
    result = (
        client.table("opinion_options")
        .select(
            "id, question_id, display_order, "
            "option_text, created_at, updated_at"
        )
        .eq("id", str(option_id))
        .eq("question_id", str(question_id))
        .maybe_single()
        .execute()
    )

    if not result or not result.data:
        raise NotFoundError(
            "Opinion option not found"
        )

    return result.data


def _reorder_rows(
    client,
    table_name: str,
    foreign_key_name: str,
    foreign_key_value: UUID,
    items: list,
) -> None:
    # Step 1: Shift existing orders into high positive numbers to prevent unique collision
    # (avoiding negative values so check constraints like display_order >= 0 do not fail)
    OFFSET = 10000
    
    for item in items:
        (
            client.table(table_name)
            .update({"display_order": item.display_order + OFFSET})
            .eq("id", str(item.id))
            .eq(foreign_key_name, str(foreign_key_value))
            .execute()
        )

    # Step 2: Apply the final desired display order
    for item in items:
        (
            client.table(table_name)
            .update({"display_order": item.display_order})
            .eq("id", str(item.id))
            .eq(foreign_key_name, str(foreign_key_value))
            .execute()
        )


# ============================================================
# QUIZ MANAGEMENT
# ============================================================


@router.get(
    "/quizzes",
    response_model=list[SuperadminQuizListItem],
)
async def list_quizzes(
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    result = (
        client.table("quizzes")
        .select(
            "id, article_id, title, created_at, updated_at"
        )
        .order("created_at", desc=True)
        .execute()
    )

    return [
        {**quiz, "title": quiz.get("title") or "Quiz"}
        for quiz in (result.data or [])
    ]



@router.get(
    "/quizzes/{quiz_id}",
    response_model=SuperadminQuizDetailResponse,
)
async def get_quiz(
    quiz_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    quiz = _get_quiz(
        client,
        quiz_id,
    )

    questions_result = (
        client.table("quiz_questions")
        .select(
            "id, quiz_id, display_order, "
            "question_text, created_at, updated_at"
        )
        .eq("quiz_id", str(quiz_id))
        .order("display_order")
        .execute()
    )

    questions = []

    for question in questions_result.data or []:
        options_result = (
            client.table("quiz_options")
            .select(
                "id, question_id, display_order, "
                "is_correct, option_text, explanation, created_at, updated_at"
            )
            .eq(
                "question_id",
                str(question["id"]),
            )
            .order("display_order")
            .execute()
        )

        options = [
            SuperadminQuizOptionResponse(
                id=option["id"],
                question_id=option["question_id"],
                display_order=option["display_order"],
                is_correct=option["is_correct"],
                option_text=option.get("option_text"),
                explanation=option.get("explanation"),
                created_at=option["created_at"],
                updated_at=option["updated_at"],
            )
            for option in (
                options_result.data or []
            )
        ]

        questions.append(
            SuperadminQuizQuestionResponse(
                id=question["id"],
                quiz_id=question["quiz_id"],
                display_order=question["display_order"],
                question_text=question.get("question_text"),
                created_at=question["created_at"],
                updated_at=question["updated_at"],
                options=options,
            )
        )

    return SuperadminQuizDetailResponse(
        id=quiz["id"],
        article_id=quiz["article_id"],
        created_at=quiz["created_at"],
        updated_at=quiz["updated_at"],
        questions=questions,
    )


@router.post(
    "/quizzes",
    response_model=SuperadminQuizDetailResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_quiz(
    payload: SuperadminQuizCreate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _article_exists(
        client,
        payload.article_id,
    )

    existing = (
        client.table("quizzes")
        .select("id")
        .eq(
            "article_id",
            str(payload.article_id),
        )
        .maybe_single()
        .execute()
    )

    if existing and existing.data:
        raise AuthorizationError(
            "This article already has a quiz"
        )

    result = (
        client.table("quizzes")
        .insert(
            {
                "article_id": str(
                    payload.article_id
                ),
                "title": payload.title,
            }
        )
        .select(
            "id, article_id, created_at, updated_at"
        )
        .execute()
    )

    quiz = extract_single_record(result.data, "Quiz creation failed")
    quiz_id = UUID(str(quiz["id"]))

    _audit(
        auth,
        action="QUIZ_CREATED",
        entity_type="QUIZ",
        entity_id=quiz_id,
        metadata={
            "article_id": str(payload.article_id),
        },
    )

    return SuperadminQuizDetailResponse(
        id=quiz["id"],
        article_id=quiz["article_id"],
        created_at=quiz["created_at"],
        updated_at=quiz["updated_at"],
        questions=[],
    )


@router.patch(
    "/quizzes/{quiz_id}",
    response_model=SuperadminQuizListItem,
)
async def update_quiz(
    quiz_id: UUID,
    payload: SuperadminQuizUpdate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    quiz = _get_quiz(
        client,
        quiz_id,
    )

    update_data = {}

    if payload.title is not None:
        update_data["title"] = payload.title.strip()

    if payload.article_id is not None:
        _article_exists(
            client,
            payload.article_id,
        )

        existing = (
            client.table("quizzes")
            .select("id")
            .eq(
                "article_id",
                str(payload.article_id),
            )
            .neq("id", str(quiz_id))
            .maybe_single()
            .execute()
        )

        if existing and existing.data:
            raise AuthorizationError(
                "This article already has a quiz"
            )

        update_data["article_id"] = str(
            payload.article_id
        )

    if update_data:
        result = (
            client.table("quizzes")
            .update(update_data)
            .eq("id", str(quiz_id))
            .select(
                "id, article_id, created_at, updated_at"
            )
            .execute()
        )

        if result and isinstance(result.data, (dict, list)):
            updated_quiz = extract_single_record(result.data, "Quiz update failed")
        else:
            updated_quiz = {**quiz, **update_data}

        _audit(
            auth,
            action="QUIZ_UPDATED",
            entity_type="QUIZ",
            entity_id=quiz_id,
            metadata={
                "before_article_id": str(
                    quiz["article_id"]
                ),
                "after_article_id": str(
                    updated_quiz["article_id"]
                ),
                "changes": update_data,
            },
        )

        return updated_quiz

    return quiz


@router.delete(
    "/quizzes/{quiz_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_quiz(
    quiz_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    quiz = _get_quiz(
        auth.client,
        quiz_id,
    )

    (
        auth.client.table("quizzes")
        .delete()
        .eq("id", str(quiz_id))
        .execute()
    )

    _audit(
        auth,
        action="QUIZ_DELETED",
        entity_type="QUIZ",
        entity_id=quiz_id,
        metadata={
            "article_id": str(quiz["article_id"]),
        },
    )


# ============================================================
# QUIZ QUESTIONS
# ============================================================


@router.get(
    "/quizzes/{quiz_id}/questions",
    response_model=list[SuperadminQuizQuestionResponse],
)
async def list_quiz_questions(
    quiz_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_quiz(
        client,
        quiz_id,
    )

    result = (
        client.table("quiz_questions")
        .select(
            "id, quiz_id, display_order, "
            "question_text, created_at, updated_at"
        )
        .eq("quiz_id", str(quiz_id))
        .order("display_order")
        .execute()
    )

    output = []

    for question in result.data or []:
        options_result = (
            client.table("quiz_options")
            .select(
                "id, question_id, display_order, "
                "is_correct, option_text, explanation, created_at, updated_at"
            )
            .eq(
                "question_id",
                str(question["id"]),
            )
            .order("display_order")
            .execute()
        )

        output.append(
            SuperadminQuizQuestionResponse(
                id=question["id"],
                quiz_id=question["quiz_id"],
                display_order=question["display_order"],
                question_text=question.get("question_text"),
                created_at=question["created_at"],
                updated_at=question["updated_at"],
                options=[
                    SuperadminQuizOptionResponse(
                        id=option["id"],
                        question_id=option["question_id"],
                        display_order=option[
                            "display_order"
                        ],
                        is_correct=option["is_correct"],
                        option_text=option.get("option_text"),
                        created_at=option["created_at"],
                        updated_at=option["updated_at"],
                    )
                    for option in (
                        options_result.data or []
                    )
                ],
            )
        )

    return output


@router.post(
    "/quizzes/{quiz_id}/questions",
    response_model=SuperadminQuizQuestionResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_quiz_question(
    quiz_id: UUID,
    payload: SuperadminQuizQuestionCreate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_quiz(
        client,
        quiz_id,
    )

    result = (
        client.table("quiz_questions")
        .insert(
            {
                "quiz_id": str(quiz_id),
                "display_order": payload.display_order,
                "question_text": payload.question_text,
            }
        )
        .select(
            "id, quiz_id, display_order, "
            "question_text, created_at, updated_at"
        )
        .execute()
    )

    question = extract_single_record(result.data, "Quiz question creation failed")
    question_id = UUID(str(question["id"]))

    _audit(
        auth,
        action="QUIZ_QUESTION_CREATED",
        entity_type="QUIZ_QUESTION",
        entity_id=question_id,
        metadata={
            "quiz_id": str(quiz_id),
            "display_order": payload.display_order,
                "question_text": payload.question_text,
            "question_text": payload.question_text,
        },
    )

    return SuperadminQuizQuestionResponse(
        id=question["id"],
        quiz_id=question["quiz_id"],
        display_order=question["display_order"],
        question_text=payload.question_text,
        created_at=question["created_at"],
        updated_at=question["updated_at"],
        options=[],
    )

# ============================================================
# QUIZ QUESTIONS — REORDER
# IMPORTANT: Place this route ABOVE any dynamic /{question_id} routes!
# ============================================================

@router.patch(
    "/quizzes/{quiz_id}/questions/reorder",
    response_model=list[SuperadminQuizQuestionResponse],
)
async def reorder_quiz_questions(
    quiz_id: UUID,
    payload: SuperadminQuizQuestionReorder,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    # Verify target quiz exists
    _get_quiz(client, quiz_id)

    if not payload.items:
        raise HTTPException(
            status_code=422,
            detail="At least one question item is required",
        )

    # Validate duplicate inputs in the payload
    item_ids = [item.id for item in payload.items]
    display_orders = [item.display_order for item in payload.items]

    if len(item_ids) != len(set(item_ids)):
        raise HTTPException(
            status_code=422,
            detail="Duplicate question IDs are not allowed in payload",
        )

    if len(display_orders) != len(set(display_orders)):
        raise HTTPException(
            status_code=422,
            detail="Duplicate display_order values are not allowed in payload",
        )

    # Fetch existing questions from database
    existing = (
        client.table("quiz_questions")
        .select("id")
        .eq("quiz_id", str(quiz_id))
        .execute()
    )

    existing_ids = {
        UUID(str(row["id"]))
        for row in (existing.data or [])
        if isinstance(row, dict) and "id" in row
    }

    supplied_ids = set(item_ids)

    # Ensure all questions for this quiz are present
    if existing_ids != supplied_ids:
        missing_ids = [str(i) for i in (existing_ids - supplied_ids)]
        invalid_ids = [str(i) for i in (supplied_ids - existing_ids)]

        detail_msg = "Reorder payload must contain every question belonging to the quiz exactly once."
        if missing_ids:
            detail_msg += f" Missing Question IDs: {missing_ids}"
        if invalid_ids:
            detail_msg += f" Invalid Question IDs: {invalid_ids}"

        raise HTTPException(
            status_code=422,
            detail=detail_msg,
        )

    # Apply positive offset first (10000 + index) to prevent unique key collisions 
    # and satisfy non-negative CHECK constraints
    for index, item in enumerate(payload.items):
        (
            client.table("quiz_questions")
            .update({"display_order": 10000 + index + 1})
            .eq("id", str(item.id))
            .eq("quiz_id", str(quiz_id))
            .execute()
        )

    # Assign final display orders
    for item in payload.items:
        (
            client.table("quiz_questions")
            .update({"display_order": item.display_order})
            .eq("id", str(item.id))
            .eq("quiz_id", str(quiz_id))
            .execute()
        )

    # Audit logging
    try:
        _audit(
            auth,
            action="QUIZ_QUESTIONS_REORDERED",
            entity_type="QUIZ",
            entity_id=quiz_id,
            metadata={
                "items": [
                    {
                        "id": str(item.id),
                        "display_order": item.display_order,
                    }
                    for item in payload.items
                ],
            },
        )
    except Exception:
        pass

    # Fetch sorted questions
    response = (
        client.table("quiz_questions")
        .select("*")
        .eq("quiz_id", str(quiz_id))
        .order("display_order")
        .execute()
    )

    return response.data or []

@router.patch(
    "/quizzes/{quiz_id}/questions/{question_id}",
    response_model=SuperadminQuizQuestionResponse,
)
async def update_quiz_question(
    quiz_id: UUID,
    question_id: UUID,
    payload: SuperadminQuizQuestionUpdate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    question = _get_quiz_question(
        client,
        quiz_id,
        question_id,
    )

    update_data = {}

    if payload.display_order is not None:
        update_data["display_order"] = (
            payload.display_order
        )

    if payload.question_text is not None:
        update_data["question_text"] = payload.question_text

    if update_data:
        result = (
            client.table("quiz_questions")
            .update(update_data)
            .eq("id", str(question_id))
            .eq("quiz_id", str(quiz_id))
            .select(
                "id, quiz_id, display_order, "
            "question_text, created_at, updated_at"
            )
            .execute()
        )

        if result and isinstance(result.data, (dict, list)):
            question = extract_single_record(result.data, "Quiz question update failed")
        else:
            question = {**question, **update_data}

    _audit(
        auth,
        action="QUIZ_QUESTION_UPDATED",
        entity_type="QUIZ_QUESTION",
        entity_id=question_id,
        metadata={
            "quiz_id": str(quiz_id),
            "changes": {
                **update_data,
                **(
                    {
                        "question_text": payload.question_text
                    }
                    if payload.question_text is not None
                    else {}
                ),
            },
        },
    )

    return SuperadminQuizQuestionResponse(
        id=question["id"],
        quiz_id=question["quiz_id"],
        display_order=question["display_order"],
        question_text=(
            payload.question_text
            if payload.question_text is not None
            else question.get("question_text")
        ),
        created_at=question["created_at"],
        updated_at=question["updated_at"],
        options=[],
    )


@router.delete(
    "/quizzes/{quiz_id}/questions/{question_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_quiz_question(
    quiz_id: UUID,
    question_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    question = _get_quiz_question(
        client,
        quiz_id,
        question_id,
    )

    (
        client.table("quiz_questions")
        .delete()
        .eq("id", str(question_id))
        .eq("quiz_id", str(quiz_id))
        .execute()
    )

    _audit(
        auth,
        action="QUIZ_QUESTION_DELETED",
        entity_type="QUIZ_QUESTION",
        entity_id=question_id,
        metadata={
            "quiz_id": str(quiz_id),
            "display_order": question["display_order"],
        },
    )


@router.patch(
    "/quizzes/{quiz_id}/questions/reorder",
    status_code=status.HTTP_204_NO_CONTENT,
)



# ============================================================
# QUIZ OPTIONS
# ============================================================


@router.get(
    "/quizzes/{quiz_id}/questions/{question_id}/options",
    response_model=list[SuperadminQuizOptionResponse],
)
async def list_quiz_options(
    quiz_id: UUID,
    question_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_quiz_question(
        client,
        quiz_id,
        question_id,
    )

    result = (
        client.table("quiz_options")
        .select(
            "id, question_id, display_order, "
            "is_correct, option_text, created_at, updated_at"
        )
        .eq("question_id", str(question_id))
        .order("display_order")
        .execute()
    )

    return [
        SuperadminQuizOptionResponse(
            id=option["id"],
            question_id=option["question_id"],
            display_order=option["display_order"],
            is_correct=option["is_correct"],
            option_text=option.get("option_text"),
            created_at=option["created_at"],
            updated_at=option["updated_at"],
        )
        for option in (result.data or [])
    ]


@router.post(
    "/quizzes/{quiz_id}/questions/{question_id}/options",
    response_model=SuperadminQuizOptionResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_quiz_option(
    quiz_id: UUID,
    question_id: UUID,
    payload: SuperadminQuizOptionCreate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_quiz_question(
        client,
        quiz_id,
        question_id,
    )

    if payload.is_correct:
        (
            client.table("quiz_options")
            .update({"is_correct": False})
            .eq(
                "question_id",
                str(question_id),
            )
            .execute()
        )

    result = (
        client.table("quiz_options")
        .insert(
            {
                "question_id": str(question_id),
                "display_order": payload.display_order,
                "option_text": payload.option_text,
                "is_correct": payload.is_correct,
                "option_text": payload.option_text,
                "explanation": payload.explanation,
            }
        )
        .select(
            "id, question_id, display_order, "
            "is_correct, option_text, explanation, created_at, updated_at"
        )
        .execute()
    )

    option = extract_single_record(result.data, "Quiz option creation failed")
    option_id = UUID(str(option["id"]))

    _audit(
        auth,
        action="QUIZ_OPTION_CREATED",
        entity_type="QUIZ_OPTION",
        entity_id=option_id,
        metadata={
            "quiz_id": str(quiz_id),
            "question_id": str(question_id),
            "display_order": payload.display_order,
                "option_text": payload.option_text,
            "is_correct": payload.is_correct,
                "option_text": payload.option_text,
            "option_text": payload.option_text,
        },
    )

    return SuperadminQuizOptionResponse(
        id=option["id"],
        question_id=option["question_id"],
        display_order=option["display_order"],
        is_correct=option["is_correct"],
        option_text=payload.option_text,
        created_at=option["created_at"],
        updated_at=option["updated_at"],
    )


@router.patch(
    "/quizzes/{quiz_id}/questions/{question_id}/options/reorder",
    response_model=list[SuperadminQuizOptionResponse],
)
async def reorder_quiz_options(
    quiz_id: UUID,
    question_id: UUID,
    payload: SuperadminQuizOptionReorder,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_quiz_question(
        client,
        quiz_id,
        question_id,
    )

    if not payload.items:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="At least one option is required in the payload",
        )

    option_ids = [item.id for item in payload.items]
    display_orders = [item.display_order for item in payload.items]

    if len(option_ids) != len(set(option_ids)):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Duplicate option IDs are not allowed in payload",
        )

    if len(display_orders) != len(set(display_orders)):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Duplicate display_order values are not allowed in payload",
        )

    existing = (
        client.table("quiz_options")
        .select("id")
        .eq(
            "question_id",
            str(question_id),
        )
        .execute()
    )

    existing_ids = {
        UUID(str(row["id"]))
        for row in (existing.data or [])
        if isinstance(row, dict) and "id" in row
    }

    supplied_ids = set(option_ids)

    if existing_ids != supplied_ids:
        missing_ids = [str(i) for i in (existing_ids - supplied_ids)]
        invalid_ids = [str(i) for i in (supplied_ids - existing_ids)]

        detail_msg = "Reorder payload must contain every quiz option belonging to the question exactly once."
        if missing_ids:
            detail_msg += f" Missing Option IDs: {missing_ids}"
        if invalid_ids:
            detail_msg += f" Invalid Option IDs: {invalid_ids}"

        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=detail_msg,
        )

    try:
        for index, item in enumerate(payload.items):
            (
                client.table("quiz_options")
                .update({"display_order": 10000 + index + 1})
                .eq("id", str(item.id))
                .eq("question_id", str(question_id))
                .execute()
            )

        for item in payload.items:
            (
                client.table("quiz_options")
                .update({"display_order": item.display_order})
                .eq("id", str(item.id))
                .eq("question_id", str(question_id))
                .execute()
            )
    except APIError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Failed to update option order: {exc.message}",
        ) from exc

    try:
        _audit(
            auth,
            action="QUIZ_OPTIONS_REORDERED",
            entity_type="QUIZ_QUESTION",
            entity_id=question_id,
            metadata={
                "quiz_id": str(quiz_id),
                "items": [
                    {
                        "id": str(item.id),
                        "display_order": item.display_order,
                    }
                    for item in payload.items
                ],
            },
        )
    except Exception:
        pass

    response = (
        client.table("quiz_options")
        .select("id, display_order, option_text")
        .eq("question_id", str(question_id))
        .order("display_order")
        .execute()
    )

    return [
        QuizOptionResponse(
            id=opt["id"],
            display_order=opt["display_order"],
            option_text=opt["option_text"],
        )
        for opt in (response.data or [])
    ]

@router.patch(
    "/quizzes/{quiz_id}/questions/{question_id}/options/{option_id}",
    response_model=SuperadminQuizOptionResponse,
)
async def update_quiz_option(
    quiz_id: UUID,
    question_id: UUID,
    option_id: UUID,
    payload: SuperadminQuizOptionUpdate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    option = _get_quiz_option(
        client,
        question_id,
        option_id,
    )

    _get_quiz_question(
        client,
        quiz_id,
        question_id,
    )

    update_data = {}

    if payload.display_order is not None:
        update_data["display_order"] = payload.display_order

    if payload.is_correct is True:
        (
            client.table("quiz_options")
            .update({"is_correct": False})
            .eq(
                "question_id",
                str(question_id),
            )
            .execute()
        )

        update_data["is_correct"] = True

    elif payload.is_correct is False:
        update_data["is_correct"] = False

    if payload.option_text is not None:
        update_data["option_text"] = payload.option_text

    if payload.explanation is not None:
        update_data["explanation"] = payload.explanation

    if update_data:
        result = (
            client.table("quiz_options")
            .update(update_data)
            .eq("id", str(option_id))
            .eq(
                "question_id",
                str(question_id),
            )
            .select(
                "id, question_id, display_order, "
                "is_correct, option_text, explanation, created_at, updated_at"
            )
            .execute()
        )

        option = extract_single_record(result.data, "Quiz option update failed")

    _audit(
        auth,
        action="QUIZ_OPTION_UPDATED",
        entity_type="QUIZ_OPTION",
        entity_id=option_id,
        metadata={
            "quiz_id": str(quiz_id),
            "question_id": str(question_id),
            "changes": {
                **update_data,
                **(
                    {
                        "option_text": payload.option_text
                    }
                    if payload.option_text is not None
                    else {}
                ),
            },
        },
    )

    return SuperadminQuizOptionResponse(
        id=option["id"],
        question_id=option["question_id"],
        display_order=option["display_order"],
        is_correct=option["is_correct"],
        option_text=(
            payload.option_text
            if payload.option_text is not None
            else option.get("option_text")
        ),
        explanation=option.get("explanation"),
        created_at=option["created_at"],
        updated_at=option["updated_at"],
    )


@router.delete(
    "/quizzes/{quiz_id}/questions/{question_id}/options/{option_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_quiz_option(
    quiz_id: UUID,
    question_id: UUID,
    option_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_quiz_question(
        client,
        quiz_id,
        question_id,
    )

    option = _get_quiz_option(
        client,
        question_id,
        option_id,
    )

    (
        client.table("quiz_options")
        .delete()
        .eq("id", str(option_id))
        .eq(
            "question_id",
            str(question_id),
        )
        .execute()
    )

    _audit(
        auth,
        action="QUIZ_OPTION_DELETED",
        entity_type="QUIZ_OPTION",
        entity_id=option_id,
        metadata={
            "quiz_id": str(quiz_id),
            "question_id": str(question_id),
            "display_order": option["display_order"],
            "is_correct": option["is_correct"],
        },
    )


@router.patch(
    "/quizzes/{quiz_id}/questions/{question_id}/correct-answer",
    response_model=SuperadminQuizOptionResponse,
)
async def set_quiz_correct_answer(
    quiz_id: UUID,
    question_id: UUID,
    payload: SuperadminQuizCorrectAnswerUpdate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_quiz_question(
        client,
        quiz_id,
        question_id,
    )

    option = _get_quiz_option(
        client,
        question_id,
        payload.option_id,
    )

    (
        client.table("quiz_options")
        .update({"is_correct": False})
        .eq(
            "question_id",
            str(question_id),
        )
        .execute()
    )

    result = (
        client.table("quiz_options")
        .update({"is_correct": True})
        .eq("id", str(payload.option_id))
        .eq(
            "question_id",
            str(question_id),
        )
        .select(
            "id, question_id, display_order, "
                "is_correct, option_text, explanation, created_at, updated_at"
        )
        .execute()
    )

    option = extract_single_record(result.data, "Quiz correct answer update failed")

    _audit(
        auth,
        action="QUIZ_CORRECT_ANSWER_CHANGED",
        entity_type="QUIZ_QUESTION",
        entity_id=question_id,
        metadata={
            "quiz_id": str(quiz_id),
            "option_id": str(payload.option_id),
        },
    )

    return SuperadminQuizOptionResponse(
        id=option["id"],
        question_id=option["question_id"],
        display_order=option["display_order"],
        is_correct=option["is_correct"],
        option_text=option.get("option_text"),
        created_at=option["created_at"],
        updated_at=option["updated_at"],
    )


# ============================================================
# OPINION MANAGEMENT
# ============================================================


@router.get(
    "/opinions",
    response_model=list[SuperadminOpinionResponse],
)
async def list_opinions(
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    result = (
        client.table("opinion_questions")
        .select(
            "id, article_id, display_order, "
            "allow_custom_response, question_text, created_at, updated_at"
        )
        .order("article_id")
        .order("display_order")
        .execute()
    )

    output = []

    for opinion in result.data or []:
        options = (
            client.table("opinion_options")
            .select(
                "id, question_id, display_order, "
                "option_text, created_at, updated_at"
            )
            .eq(
                "question_id",
                str(opinion["id"]),
            )
            .order("display_order")
            .execute()
        )

        output.append(
            SuperadminOpinionResponse(
                id=opinion["id"],
                article_id=opinion["article_id"],
                display_order=opinion["display_order"],
                allow_custom_response=opinion[
                    "allow_custom_response"
                ],
                question_text=opinion.get("question_text"),
                created_at=opinion["created_at"],
                updated_at=opinion["updated_at"],
                options=[
                    SuperadminOpinionOptionResponse(
                        id=option["id"],
                        question_id=option["question_id"],
                        display_order=option[
                            "display_order"
                        ],
                        option_text=option.get("option_text"),
                        created_at=option[
                            "created_at"
                        ],
                        updated_at=option[
                            "updated_at"
                        ],
                    )
                    for option in (
                        options.data or []
                    )
                ],
            )
        )

    return output

@router.patch("/opinions/reorder",status_code=status.HTTP_204_NO_CONTENT,)
async def reorder_opinions(
    payload: SuperadminOpinionReorder,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    if not payload.items:
        return

    first = _get_opinion(
        client,
        payload.items[0].id,
    )

    article_id = first["article_id"]

    existing = (
        client.table("opinion_questions")
        .select("id")
        .eq(
            "article_id",
            str(article_id),
        )
        .execute()
    )

    existing_ids = {
        str(row["id"])
        for row in (
            existing.data or []
        )
    }

    supplied_ids = {
        str(item.id)
        for item in payload.items
    }

    if existing_ids != supplied_ids:
        raise AuthorizationError(
            "Reorder payload must contain every opinion for the article"
        )

    for item in payload.items:
        current = _get_opinion(
            client,
            item.id,
        )

        if str(current["article_id"]) != str(
            article_id
        ):
            raise AuthorizationError(
                "All opinions must belong to the same article"
            )

    _reorder_rows(
        client,
        "opinion_questions",
        "article_id",
        article_id,
        payload.items,
    )

    _audit(
        auth,
        action="OPINIONS_REORDERED",
        entity_type="ARTICLE",
        entity_id=UUID(str(article_id)),
        metadata={
            "items": [
                {
                    "id": str(item.id),
                    "display_order": item.display_order,
                }
                for item in payload.items
            ],
        },
    )


@router.get(
    "/opinions/{opinion_id}",
    response_model=SuperadminOpinionResponse,
)
async def get_opinion(
    opinion_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    opinion = _get_opinion(
        client,
        opinion_id,
    )

    options = (
        client.table("opinion_options")
        .select(
            "id, question_id, display_order, "
            "option_text, created_at, updated_at"
        )
        .eq(
            "question_id",
            str(opinion_id),
        )
        .order("display_order")
        .execute()
    )

    return SuperadminOpinionResponse(
        id=opinion["id"],
        article_id=opinion["article_id"],
        display_order=opinion["display_order"],
        allow_custom_response=opinion[
            "allow_custom_response"
        ],
        question_text=opinion.get("question_text"),
        created_at=opinion["created_at"],
        updated_at=opinion["updated_at"],
        options=[
            SuperadminOpinionOptionResponse(
                id=option["id"],
                question_id=option["question_id"],
                display_order=option["display_order"],
                option_text=option.get("option_text"),
                created_at=option["created_at"],
                updated_at=option["updated_at"],
            )
            for option in (
                options.data or []
            )
        ],
    )


@router.post(
    "/opinions",
    response_model=SuperadminOpinionResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_opinion(
    payload: SuperadminOpinionCreate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _article_exists(
        client,
        payload.article_id,
    )

    result = (
        client.table("opinion_questions")
        .insert(
            {
                "article_id": str(
                    payload.article_id
                ),
                "display_order": payload.display_order,
                "allow_custom_response": (
                    payload.allow_custom_response
                ),
                "question_text": payload.question_text,
            }
        )
        .select(
            "id, article_id, display_order, "
            "allow_custom_response, question_text, created_at, updated_at"
        )
        .execute()
    )

    opinion = extract_single_record(result.data, "Opinion question creation failed")
    opinion_id = UUID(str(opinion["id"]))

    _audit(
        auth,
        action="OPINION_CREATED",
        entity_type="OPINION",
        entity_id=opinion_id,
        metadata={
            "article_id": str(payload.article_id),
            "display_order": payload.display_order,
            "allow_custom_response": (
                payload.allow_custom_response
            ),
            "question_text": payload.question_text,
        },
    )

    return SuperadminOpinionResponse(
        id=opinion["id"],
        article_id=opinion["article_id"],
        display_order=opinion["display_order"],
        allow_custom_response=opinion[
            "allow_custom_response"
        ],
        question_text=payload.question_text,
        created_at=opinion["created_at"],
        updated_at=opinion["updated_at"],
        options=[],
    )


@router.patch(
    "/opinions/{opinion_id}",
    response_model=SuperadminOpinionResponse,
)
async def update_opinion(
    opinion_id: UUID,
    payload: SuperadminOpinionUpdate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    opinion = _get_opinion(
        client,
        opinion_id,
    )

    update_data = {}

    if payload.display_order is not None:
        update_data["display_order"] = (
            payload.display_order
        )

    if payload.question_text is not None:
        update_data["question_text"] = payload.question_text

    if payload.allow_custom_response is not None:
        update_data["allow_custom_response"] = (
            payload.allow_custom_response
        )

    if update_data:
        result = (
            client.table("opinion_questions")
            .update(update_data)
            .eq("id", str(opinion_id))
            .select(
                "id, article_id, display_order, "
            "allow_custom_response, question_text, created_at, updated_at"
            )
            .execute()
        )

        opinion = extract_single_record(result.data, "Opinion question update failed")

    _audit(
        auth,
        action="OPINION_UPDATED",
        entity_type="OPINION",
        entity_id=opinion_id,
        metadata={
            "article_id": str(opinion["article_id"]),
            "changes": {
                **update_data,
                **(
                    {
                        "question_text": payload.question_text
                    }
                    if payload.question_text is not None
                    else {}
                ),
            },
        },
    )

    return SuperadminOpinionResponse(
        id=opinion["id"],
        article_id=opinion["article_id"],
        display_order=opinion["display_order"],
        allow_custom_response=opinion[
            "allow_custom_response"
        ],
        question_text=opinion.get("question_text"),
        created_at=opinion["created_at"],
        updated_at=opinion["updated_at"],
        options=[],
    )



@router.delete(
    "/opinions/{opinion_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_opinion(
    opinion_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    opinion = _get_opinion(
        auth.client,
        opinion_id,
    )

    (
        auth.client.table("opinion_questions")
        .delete()
        .eq("id", str(opinion_id))
        .execute()
    )

    _audit(
        auth,
        action="OPINION_DELETED",
        entity_type="OPINION",
        entity_id=opinion_id,
        metadata={
            "article_id": str(opinion["article_id"]),
            "display_order": opinion["display_order"],
            "allow_custom_response": (
                opinion["allow_custom_response"]
            ),
        },
    )


# ============================================================
# OPINION OPTIONS
# ============================================================


@router.get(
    "/opinions/{opinion_id}/options",
    response_model=list[SuperadminOpinionOptionResponse],
)
async def list_opinion_options(
    opinion_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_opinion(
        client,
        opinion_id,
    )

    result = (
        client.table("opinion_options")
        .select(
            "id, question_id, display_order, "
            "option_text, created_at, updated_at"
        )
        .eq(
            "question_id",
            str(opinion_id),
        )
        .order("display_order")
        .execute()
    )

    return [
        SuperadminOpinionOptionResponse(
            id=option["id"],
            question_id=option["question_id"],
            display_order=option["display_order"],
            option_text=option.get("option_text"),
            created_at=option["created_at"],
            updated_at=option["updated_at"],
        )
        for option in (
            result.data or []
        )
    ]


@router.post(
    "/opinions/{opinion_id}/options",
    response_model=SuperadminOpinionOptionResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_opinion_option(
    opinion_id: UUID,
    payload: SuperadminOpinionOptionCreate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_opinion(
        client,
        opinion_id,
    )

    result = (
        client.table("opinion_options")
        .insert(
            {
                "question_id": str(opinion_id),
                "display_order": payload.display_order,
                "option_text": payload.option_text,
            }
        )
        .select(
            "id, question_id, display_order, "
            "option_text, created_at, updated_at"
        )
        .execute()
    )

    option = extract_single_record(result.data, "Opinion option creation failed")
    option_id = UUID(str(option["id"]))

    _audit(
        auth,
        action="OPINION_OPTION_CREATED",
        entity_type="OPINION_OPTION",
        entity_id=option_id,
        metadata={
            "opinion_id": str(opinion_id),
            "display_order": payload.display_order,
            "option_text": payload.option_text,
        },
    )

    return SuperadminOpinionOptionResponse(
        id=option["id"],
        question_id=option["question_id"],
        display_order=option["display_order"],
        option_text=payload.option_text,
        created_at=option["created_at"],
        updated_at=option["updated_at"],
    )

@router.patch(
    "/opinions/{opinion_id}/options/reorder",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def reorder_opinion_options(
    opinion_id: UUID,
    payload: SuperadminOpinionOptionReorder,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_opinion(
        client,
        opinion_id,
    )

    existing = (
        client.table("opinion_options")
        .select("id")
        .eq(
            "question_id",
            str(opinion_id),
        )
        .execute()
    )

    existing_ids = {
        str(row["id"])
        for row in (
            existing.data or []
        )
    }

    supplied_ids = {
        str(item.id)
        for item in payload.items
    }

    if existing_ids != supplied_ids:
        raise AuthorizationError(
            "Reorder payload must contain every opinion option"
        )

    _reorder_rows(
        client,
        "opinion_options",
        "question_id",
        opinion_id,
        payload.items,
    )

    _audit(
        auth,
        action="OPINION_OPTIONS_REORDERED",
        entity_type="OPINION",
        entity_id=opinion_id,
        metadata={
            "items": [
                {
                    "id": str(item.id),
                    "display_order": item.display_order,
                }
                for item in payload.items
            ],
        },
    )


@router.patch(
    "/opinions/{opinion_id}/options/{option_id}",
    response_model=SuperadminOpinionOptionResponse,
)
async def update_opinion_option(
    opinion_id: UUID,
    option_id: UUID,
    payload: SuperadminOpinionOptionUpdate,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_opinion(
        client,
        opinion_id,
    )

    option = _get_opinion_option(
        client,
        opinion_id,
        option_id,
    )

    update_data = {}

    if payload.display_order is not None:
        update_data["display_order"] = (
            payload.display_order
        )

    if payload.option_text is not None:
        update_data["option_text"] = payload.option_text

    if update_data:
        result = (
            client.table("opinion_options")
            .update(update_data)
            .eq("id", str(option_id))
            .eq(
                "question_id",
                str(opinion_id),
            )
            .select(
                "id, question_id, display_order, "
                "option_text, created_at, updated_at"
            )
            .execute()
        )
        if result and isinstance(result.data, (dict, list)):
            option = extract_single_record(result.data, "Opinion option update failed")
        else:
            option = {**option, **update_data}

    _audit(
        auth,
        action="OPINION_OPTION_UPDATED",
        entity_type="OPINION_OPTION",
        entity_id=option_id,
        metadata={
            "opinion_id": str(opinion_id),
            "changes": {
                **update_data,
                **(
                    {
                        "option_text": payload.option_text
                    }
                    if payload.option_text is not None
                    else {}
                ),
            },
        },
    )

    return SuperadminOpinionOptionResponse(
        id=option["id"],
        question_id=option["question_id"],
        display_order=option["display_order"],
        option_text=(
            payload.option_text
            if payload.option_text is not None
            else option.get("option_text")
        ),
        created_at=option["created_at"],
        updated_at=option["updated_at"],
    )


@router.delete(
    "/opinions/{opinion_id}/options/{option_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_opinion_option(
    opinion_id: UUID,
    option_id: UUID,
    auth: AuthContext = Depends(get_current_user),
):
    _require_superadmin(auth)

    client = auth.client

    _get_opinion(
        client,
        opinion_id,
    )

    option = _get_opinion_option(
        client,
        opinion_id,
        option_id,
    )

    (
        client.table("opinion_options")
        .delete()
        .eq("id", str(option_id))
        .eq(
            "question_id",
            str(opinion_id),
        )
        .execute()
    )

    _audit(
        auth,
        action="OPINION_OPTION_DELETED",
        entity_type="OPINION_OPTION",
        entity_id=option_id,
        metadata={
            "opinion_id": str(opinion_id),
            "display_order": option["display_order"],
        },
    )


