from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.responses import RedirectResponse

from app.core.db_utils import extract_single_record
from app.core.exceptions import AuthorizationError, NotFoundError
from app.db.supabase import supabase, supabase_admin
from app.dependencies.auth import AuthContext, get_current_user
from app.schemas.advertisements import (
    AdvertisementCreate,
    AdvertisementResponse,
    AdvertisementSlotCreate,
    AdvertisementSlotResponse,
    AdvertisementSlotUpdate,
    AdvertisementUpdate,
)
from app.services.analytics import record_advertisement_click
from app.services.audit import record_audit
from app.services.media_urls import attach_signed_url


router = APIRouter(
    prefix="/api/v1/advertisements",
    tags=["Advertisements"],
)


def _require_superadmin(context: AuthContext) -> None:
    user_role = getattr(context.user, "role", None)

    if user_role != "SUPERADMIN":
        raise AuthorizationError(
            "Superadmin access required"
        )


def _build_slot_select_query() -> str:
    return """
        id,
        key,
        name,
        description,
        is_active,
        created_at,
        updated_at
    """


def _normalize_slot(item: dict) -> dict:
    if not item.get("placement"):
        key = str(item.get("key") or "").upper()
        item["placement"] = (
            "hero"
            if "HERO" in key
            else "article"
            if "ARTICLE" in key
            else "sidebar"
        )
    return item


def _build_ad_select_query() -> str:
    return """
        id,
        slot_id,
        image_media_id,
        title,
        description,
        destination_url,
        starts_at,
        ends_at,
        is_active,
        display_order,
        created_at,
        updated_at,

        slot:advertisement_slots (
            id,
            key,
            name,
            description,
            placement,
            is_active,
            created_at,
            updated_at
        ),

        image:media_assets (
            id,
            storage_path
        )
    """


def _parse_datetime(value):
    if not value:
        return None

    if isinstance(value, datetime):
        return value

    return datetime.fromisoformat(
        value.replace("Z", "+00:00")
    )


def _validate_visibility_window(
    starts_at,
    ends_at,
) -> None:
    starts_at = _parse_datetime(starts_at)
    ends_at = _parse_datetime(ends_at)

    if starts_at and ends_at and ends_at <= starts_at:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="ends_at must be later than starts_at",
        )


def _validate_media(
    client,
    image_media_id: UUID,
) -> None:
    result = (
        client
        .table("media_assets")
        .select("id, storage_path")
        .eq("id", str(image_media_id))
        .maybe_single()
        .execute()
    )

    if not result.data:
        raise NotFoundError(
            "Advertisement image media not found"
        )


def _resolve_media_id(client, value: str) -> str:
    try:
        media_id = UUID(str(value))
        media_filter = ("id", str(media_id))
    except ValueError:
        media_filter = ("storage_path", str(value).strip())

    result = (
        client.table("media_assets")
        .select("id")
        .eq(*media_filter)
        .maybe_single()
        .execute()
    )
    if not result.data:
        raise NotFoundError("Advertisement image media not found")
    return str(result.data["id"])


def _validate_slot(
    client,
    slot_id: UUID,
) -> None:
    result = (
        client
        .table("advertisement_slots")
        .select(_build_slot_select_query())
        .eq("id", str(slot_id))
        .maybe_single()
        .execute()
    )

    if not result.data:
        raise NotFoundError(
            "Advertisement slot not found"
        )


# ============================================================
# PUBLIC ADVERTISEMENT RETRIEVAL
# ============================================================

@router.get(
    "",
    response_model=list[AdvertisementResponse],
)
def list_advertisements(
    slot: str | None = None,
):
    """
    Return currently eligible advertisements.
    """
    # Use standard select query without corrupting the relationship alias
    query = (
        supabase
        .table("advertisements")
        .select(_build_ad_select_query())
    )

    result = (
        query
        .eq("is_active", True)
        .order("display_order", desc=False)
        .order("created_at", desc=True)
        .execute()
    )

    advertisements = result.data or []

    now = datetime.now(timezone.utc)
    visible = []

    for advertisement in advertisements:
        starts_at = _parse_datetime(advertisement.get("starts_at"))
        ends_at = _parse_datetime(advertisement.get("ends_at"))

        if starts_at and starts_at > now:
            continue

        if ends_at and ends_at <= now:
            continue

        slot_data = advertisement.get("slot") or {}

        if not slot_data.get("is_active", False):
            continue

        if not advertisement.get("is_active", False):
            continue

        # Filter by slot key cleanly in Python if parameter provided
        if slot is not None and slot_data.get("key") != slot:
            continue

        if advertisement.get("image"):
            advertisement["image"] = attach_signed_url(
                advertisement["image"]
            )

        visible.append(advertisement)

    return visible


# ============================================================
# PUBLIC SLOT RETRIEVAL
# ============================================================

@router.get(
    "/slots",
    response_model=list[AdvertisementSlotResponse],
)
def list_advertisement_slots():
    """
    Return active advertisement slots.
    """

    result = (
        supabase
        .table("advertisement_slots")
        .select(_build_slot_select_query())
        .eq("is_active", True)
        .order("key", desc=False)
        .execute()
    )

    items = result.data or []
    for item in items:
        _normalize_slot(item)
        if item.get("image"):
            item["image"] = attach_signed_url(item["image"])
    return items


# ============================================================
# SUPERADMIN ADVERTISEMENT LIST
# ============================================================

@router.get(
    "/admin",
    response_model=list[AdvertisementResponse],
)
def list_advertisements_admin(
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Return all advertisements for Superadmin management.
    """

    _require_superadmin(current_user)

    result = (
        supabase_admin
        .table("advertisements")
        .select(_build_ad_select_query())
        .order("display_order", desc=False)
        .order("created_at", desc=True)
        .execute()
    )

    items = result.data or []
    for item in items:
        slot = item.get("slot")
        if isinstance(slot, dict):
            _normalize_slot(slot)
        if item.get("image"):
            item["image"] = attach_signed_url(item["image"])
    return items


# ============================================================
# PUBLIC ADVERTISEMENT CLICK
# ============================================================

@router.get(
    "/{advertisement_id}/click",
)
def click_advertisement(
    advertisement_id: UUID,
):
    """
    Record an advertisement click and redirect the visitor
    to the advertisement destination URL.

    This endpoint is intentionally public because advertisements
    can be clicked by anonymous visitors.

    Authentication-aware attribution will be added through the
    optional-auth dependency so authenticated clicks can also
    contribute to unique-clicker analytics.
    """

    result = (
        supabase
        .table("advertisements")
        .select(
            """
            id,
            destination_url,
            starts_at,
            ends_at,
            is_active,
            slot:advertisement_slots (
                id,
                is_active
            )
            """
        )
        .eq("id", str(advertisement_id))
        .maybe_single()
        .execute()
    )

    advertisement = result.data

    if not advertisement:
        raise NotFoundError(
            "Advertisement not found"
        )

    now = datetime.now(timezone.utc)

    starts_at = _parse_datetime(
        advertisement.get("starts_at")
    )

    ends_at = _parse_datetime(
        advertisement.get("ends_at")
    )

    if starts_at and starts_at > now:
        raise NotFoundError(
            "Advertisement not found"
        )

    if ends_at and ends_at <= now:
        raise NotFoundError(
            "Advertisement not found"
        )

    if not advertisement.get("is_active", False):
        raise NotFoundError(
            "Advertisement not found"
        )

    slot = advertisement.get("slot") or {}

    if not slot.get("is_active", False):
        raise NotFoundError(
            "Advertisement not found"
        )

    destination_url = advertisement.get(
        "destination_url"
    )

    if not destination_url:
        raise NotFoundError(
            "Advertisement destination not found"
        )

    # Record the successful click.
    #
    # user_id will be supplied by optional authentication once
    # the shared auth dependency is extended.
    record_advertisement_click(
        advertisement_id=advertisement_id,
        user_id=None,
    )

    return RedirectResponse(
        url=destination_url,
        status_code=status.HTTP_307_TEMPORARY_REDIRECT,
    )


# ============================================================
# SUPERADMIN SINGLE ADVERTISEMENT
# ============================================================

@router.get(
    "/admin/{advertisement_id}",
    response_model=AdvertisementResponse,
)
def get_advertisement_admin(
    advertisement_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Return one advertisement for Superadmin management.
    """

    _require_superadmin(current_user)

    result = (
        current_user.client
        .table("advertisements")
        .select(_build_ad_select_query())
        .eq("id", str(advertisement_id))
        .maybe_single()
        .execute()
    )

    if not result.data:
        raise NotFoundError(
            "Advertisement not found"
        )

    return result.data


# ============================================================
# SUPERADMIN CREATE
# ============================================================

@router.post(
    "",
    response_model=AdvertisementResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_advertisement(
    payload: AdvertisementCreate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Create an advertisement.
    """

    _require_superadmin(current_user)

    _validate_visibility_window(
        payload.starts_at,
        payload.ends_at,
    )

    _validate_slot(
        current_user.client,
        payload.slot_id,
    )

    data = payload.model_dump(mode="json")
    data["image_media_id"] = _resolve_media_id(
        current_user.client,
        payload.image_media_id,
    )

    data["destination_url"] = str(
        payload.destination_url
    )

    result = (
        current_user.client
        .table("advertisements")
        .insert(data)
        .select(_build_ad_select_query())
        .execute()
    )

    advertisement = extract_single_record(result.data, "Advertisement could not be created")

    record_audit(
        actor_user_id=current_user.user.id,
        action="ADVERTISEMENT_CREATED",
        entity_type="ADVERTISEMENT",
        entity_id=UUID(str(advertisement["id"])),
        metadata={
            "slot_id": advertisement.get("slot_id"),
            "image_media_id": advertisement.get("image_media_id"),
            "title": advertisement.get("title"),
            "description": advertisement.get("description"),
            "destination_url": advertisement.get("destination_url"),
            "starts_at": advertisement.get("starts_at"),
            "ends_at": advertisement.get("ends_at"),
            "is_active": advertisement.get("is_active"),
            "display_order": advertisement.get("display_order"),
        },
        client=current_user.client,
    )

    return advertisement


# ============================================================
# SUPERADMIN UPDATE
# ============================================================

@router.patch(
    "/{advertisement_id}",
    response_model=AdvertisementResponse,
)
def update_advertisement(
    advertisement_id: UUID,
    payload: AdvertisementUpdate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Update an advertisement.
    """

    _require_superadmin(current_user)

    existing_result = (
        current_user.client
        .table("advertisements")
        .select("*")
        .eq("id", str(advertisement_id))
        .maybe_single()
        .execute()
    )

    if not existing_result.data:
        raise NotFoundError(
            "Advertisement not found"
        )

    existing = existing_result.data

    merged_starts_at = payload.starts_at

    if "starts_at" not in payload.model_fields_set:
        merged_starts_at = existing.get("starts_at")

    merged_ends_at = payload.ends_at

    if "ends_at" not in payload.model_fields_set:
        merged_ends_at = existing.get("ends_at")

    _validate_visibility_window(
        merged_starts_at,
        merged_ends_at,
    )

    if "slot_id" in payload.model_fields_set:
        if payload.slot_id is not None:
            _validate_slot(
                current_user.client,
                payload.slot_id,
            )

    data = payload.model_dump(
        mode="json",
        exclude_unset=True,
    )

    if data.get("image_media_id") is not None:
        data["image_media_id"] = _resolve_media_id(
            current_user.client,
            data["image_media_id"],
        )

    if (
        "destination_url" in data
        and data["destination_url"] is not None
    ):
        data["destination_url"] = str(
            payload.destination_url
        )

    result = (
        supabase_admin
        .table("advertisements")
        .update(data)
        .eq("id", str(advertisement_id))
        .select(_build_ad_select_query())
        .execute()
    )

    advertisement = extract_single_record(result.data, "Advertisement not found")

    record_audit(
        actor_user_id=current_user.user.id,
        action="ADVERTISEMENT_UPDATED",
        entity_type="ADVERTISEMENT",
        entity_id=advertisement_id,
        metadata={
            "slot_id": advertisement.get("slot_id"),
            "image_media_id": advertisement.get("image_media_id"),
            "title": advertisement.get("title"),
            "description": advertisement.get("description"),
            "destination_url": advertisement.get("destination_url"),
            "starts_at": advertisement.get("starts_at"),
            "ends_at": advertisement.get("ends_at"),
            "is_active": advertisement.get("is_active"),
            "display_order": advertisement.get("display_order"),
        },
        client=current_user.client,
    )

    return advertisement


# ============================================================
# SUPERADMIN DELETE
# ============================================================

@router.delete(
    "/{advertisement_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_advertisement(
    advertisement_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Delete an advertisement.
    """

    _require_superadmin(current_user)

    existing_result = (
        current_user.client
        .table("advertisements")
        .select("*")
        .eq("id", str(advertisement_id))
        .maybe_single()
        .execute()
    )

    if not existing_result.data:
        raise NotFoundError(
            "Advertisement not found"
        )

    existing = existing_result.data

    (
        current_user.client
        .table("advertisements")
        .delete()
        .eq("id", str(advertisement_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ADVERTISEMENT_DELETED",
        entity_type="ADVERTISEMENT",
        entity_id=advertisement_id,
        metadata={
            "slot_id": existing.get("slot_id"),
            "image_media_id": existing.get("image_media_id"),
            "title": existing.get("title"),
            "description": existing.get("description"),
            "destination_url": existing.get("destination_url"),
            "starts_at": existing.get("starts_at"),
            "ends_at": existing.get("ends_at"),
            "is_active": existing.get("is_active"),
            "display_order": existing.get("display_order"),
        },
        client=current_user.client,
    )

    return None


# ============================================================
# SUPERADMIN SLOT MANAGEMENT
# ============================================================

@router.get(
    "/slots/admin",
    response_model=list[AdvertisementSlotResponse],
)
def list_advertisement_slots_admin(
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Return all advertisement slots for Superadmin management.
    """

    _require_superadmin(current_user)

    result = (
        current_user.client
        .table("advertisement_slots")
        .select(_build_slot_select_query())
        .order("key", desc=False)
        .execute()
    )

    items = result.data or []
    for item in items:
        _normalize_slot(item)
    return items


@router.post(
    "/slots",
    response_model=AdvertisementSlotResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_advertisement_slot(
    payload: AdvertisementSlotCreate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Create an advertisement slot.
    """

    _require_superadmin(current_user)

    data = payload.model_dump()

    data["key"] = data["key"].strip()
    data["name"] = data["name"].strip()

    if data.get("description") is not None:
        data["description"] = data["description"].strip()

    result = (
        current_user.client
        .table("advertisement_slots")
        .insert(data)
        .select(_build_slot_select_query())
        .execute()
    )

    slot = extract_single_record(result.data, "Advertisement slot could not be created")

    record_audit(
        actor_user_id=current_user.user.id,
        action="ADVERTISEMENT_SLOT_CREATED",
        entity_type="ADVERTISEMENT_SLOT",
        entity_id=UUID(str(slot["id"])),
        metadata={
            "key": slot.get("key"),
            "name": slot.get("name"),
            "description": slot.get("description"),
            "is_active": slot.get("is_active"),
        },
        client=current_user.client,
    )

    return slot


@router.patch(
    "/slots/{slot_id}",
    response_model=AdvertisementSlotResponse,
)
def update_advertisement_slot(
    slot_id: UUID,
    payload: AdvertisementSlotUpdate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Update an advertisement slot.
    """

    _require_superadmin(current_user)

    existing_result = (
        current_user.client
        .table("advertisement_slots")
        .select("*")
        .eq("id", str(slot_id))
        .maybe_single()
        .execute()
    )

    if not existing_result.data:
        raise NotFoundError(
            "Advertisement slot not found"
        )

    data = payload.model_dump(
        exclude_unset=True
    )

    if "key" in data and data["key"] is not None:
        data["key"] = data["key"].strip()

    if "name" in data and data["name"] is not None:
        data["name"] = data["name"].strip()

    if (
        "description" in data
        and data["description"] is not None
    ):
        data["description"] = data["description"].strip()

    result = (
        current_user.client
        .table("advertisement_slots")
        .update(data)
        .eq("id", str(slot_id))
        .select(_build_slot_select_query())
        .execute()
    )

    slot = extract_single_record(result.data, "Advertisement slot not found")

    record_audit(
        actor_user_id=current_user.user.id,
        action="ADVERTISEMENT_SLOT_UPDATED",
        entity_type="ADVERTISEMENT_SLOT",
        entity_id=slot_id,
        metadata={
            "key": slot.get("key"),
            "name": slot.get("name"),
            "description": slot.get("description"),
            "is_active": slot.get("is_active"),
        },
        client=current_user.client,
    )

    return slot


@router.delete(
    "/slots/{slot_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_advertisement_slot(
    slot_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    """
    Delete an advertisement slot.
    """

    _require_superadmin(current_user)

    existing_result = (
        current_user.client
        .table("advertisement_slots")
        .select("*")
        .eq("id", str(slot_id))
        .maybe_single()
        .execute()
    )

    if not existing_result.data:
        raise NotFoundError(
            "Advertisement slot not found"
        )

    existing = existing_result.data

    (
        current_user.client
        .table("advertisement_slots")
        .delete()
        .eq("id", str(slot_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ADVERTISEMENT_SLOT_DELETED",
        entity_type="ADVERTISEMENT_SLOT",
        entity_id=slot_id,
        metadata={
            "key": existing.get("key"),
            "name": existing.get("name"),
            "description": existing.get("description"),
            "is_active": existing.get("is_active"),
        },
        client=current_user.client,
    )

    return None