import logging
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from re import sub
from uuid import UUID, uuid4

from fastapi import APIRouter, Depends, Query, status
from fastapi import HTTPException
from postgrest.exceptions import APIError

from app.core.db_utils import extract_single_record
from app.core.exceptions import AuthorizationError, NotFoundError
from app.dependencies.auth import AuthContext, get_current_user
from app.schemas.superadmin_content import (
    SuperadminArticleBlockCreate,
    SuperadminArticleBlockReorder,
    SuperadminArticleBlockResponse,
    SuperadminArticleBlockUpdate,
    SuperadminArticleCreate,
    SuperadminArticleDetailResponse,
    SuperadminArticleListItem,
    SuperadminArticleStatusUpdate,
    SuperadminArticleUpdate,
    SuperadminAuthorPickUpdate,
    SuperadminCategoryCreate,
    SuperadminCategoryResponse,
    SuperadminCategoryUpdate,
    SuperadminHomeResponse,
)
from app.services.audit import record_audit
from app.services.media_urls import create_signed_url


router = APIRouter(
    prefix="/api/v1/superadmin",
    tags=["Superadmin Content"],
)

logger = logging.getLogger("app.superadmin_content")

INDIA_TIMEZONE = ZoneInfo("Asia/Kolkata")


def _schedule_as_utc(value: datetime) -> datetime:
    """Interpret admin datetime-local values as IST and persist UTC."""
    if value.tzinfo is None:
        value = value.replace(tzinfo=INDIA_TIMEZONE)
    return value.astimezone(timezone.utc)


# ============================================================
# AUTHORIZATION
# ============================================================

def _require_superadmin(
    context: AuthContext,
) -> None:
    role = getattr(
        context.user,
        "role",
        None,
    )

    if role != "SUPERADMIN":
        raise AuthorizationError(
            "Superadmin access required"
        )


# ============================================================
# HELPERS
# ============================================================

CATEGORY_SELECT = """
    id,
    name,
    slug,
    description,
    display_order,
    is_active,
    created_at,
    updated_at,
    image_url
"""


ARTICLE_SELECT = """
    id,
    category_id,
    article_type,
    status,
    cover_media_id,
    created_by,
    updated_by,
    created_at,
    updated_at,
    published_at,
    scheduled_at,
    is_author_pick,
    author_pick_order,
    cover_image_url,
    is_featured,
    author_name,
    reading_time_minutes,
    categories (
        id,
        name,
        slug,
        description,
        display_order,
        is_active,
        created_at,
        is_active,
        created_at,
        updated_at
    ),
    title,
    subtitle,
    summary,
    slug
"""


ARTICLE_BLOCK_SELECT = """
    id,
    article_id,
    block_type,
    display_order,
    media_id,
    quiz_id,
    opinion_id,
    external_url,
    text_content,
    caption,
    title,
    created_at,
    updated_at,
    media_assets (
        id,
        storage_path,
        media_type,
        mime_type
    )
"""


ALLOWED_BLOCK_TYPES = {
    "TEXT",
    "IMAGE",
    "PODCAST",
    "QUIZ",
    "OPINION",
}


def _map_article(data: dict) -> dict:
    return {
        "id": data["id"],
        "category_id": data["category_id"],
        "title": data.get("title"),
        "media_url": create_signed_url((data.get("media_assets") or {}).get("storage_path")),
        "subtitle": data.get("subtitle"),
        "summary": data.get("summary"),
        "slug": data.get("slug"),
        "article_type": data["article_type"],
        "status": data["status"],
        "cover_media_id": data.get("cover_media_id"),
        "created_by": data.get("created_by"),
        "updated_by": data.get("updated_by"),
        "created_at": data["created_at"],
        "updated_at": data["updated_at"],
        "published_at": data.get("published_at"),
        "scheduled_at": data.get("scheduled_at"),
        "is_author_pick": data.get(
            "is_author_pick",
            False,
        ),
        "author_pick_order": data.get(
            "author_pick_order"
        ),
        "cover_image_url": data.get("cover_image_url"),
        "is_featured": bool(data.get("is_featured")),
        "author_name": data.get("author_name"),
        "reading_time_minutes": data.get("reading_time_minutes"),
        "category": data.get("categories"),
    }


def _map_block(data: dict) -> dict:
    return {
        "id": data["id"],
        "article_id": data["article_id"],
        "block_type": data["block_type"],
        "display_order": data["display_order"],
        "media_id": data.get("media_id"),
        "quiz_id": data.get("quiz_id"),
        "opinion_id": data.get("opinion_id"),
        "external_url": data.get("external_url"),
        "text_content": data.get("text_content"),
        "caption": data.get("caption"),
        "title": data.get("title"),
    }


def _validate_article_status(
    value: str,
) -> None:
    allowed = {
        "DRAFT",
        "PENDING_REVIEW",
        "REJECTED",
        "PUBLISHED",
        "UNPUBLISHED",
        "SCHEDULED",
        "ARCHIVED",
    }

    if value not in allowed:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=f"Invalid article status: {value}",
        )


def _validate_article_type(
    value: str,
) -> None:
    allowed = {
        "STANDARD",
        "QUIZ",
        "OPINION",
        "PODCAST",
        "ARTICLE",
        "FEATURED",
    }

    if value not in allowed:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=f"Invalid article type: {value}",
        )


def _normalize_article_type(value: str) -> tuple[str, bool]:
    if value == "ARTICLE":
        return "STANDARD", False
    if value == "FEATURED":
        return "STANDARD", True
    return value, value == "FEATURED"


def _slugify_title(title: str) -> str:
    slug = sub(r"[^a-z0-9]+", "-", title.lower()).strip("-")
    return f"{slug or 'article'}-{uuid4().hex[:8]}"


def _validate_block_type(
    value: str,
) -> None:
    if value not in ALLOWED_BLOCK_TYPES:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=f"Invalid article block type: {value}",
        )


def _get_article(
    client,
    article_id: UUID,
):
    response = (
        client
        .table("articles")
        .select(ARTICLE_SELECT)
        .eq("id", str(article_id))
        .maybe_single()
        .execute()
    )

    if response is None or not response.data:
        raise NotFoundError(
            "Article not found"
        )

    return response.data


def _get_category(
    client,
    category_id: UUID,
):
    response = (
        client
        .table("categories")
        .select(CATEGORY_SELECT)
        .eq("id", str(category_id))
        .maybe_single()
        .execute()
    )

    if response is None or not response.data:
        raise NotFoundError(
            "Category not found"
        )

    return response.data


def _get_article_block(
    client,
    article_id: UUID,
    block_id: UUID,
):
    response = (
        client
        .table("article_blocks")
        .select(ARTICLE_BLOCK_SELECT)
        .eq("id", str(block_id))
        .eq("article_id", str(article_id))
        .maybe_single()
        .execute()
    )

    if response is None or not response.data:
        raise NotFoundError(
            "Article block not found"
        )

    return response.data


def _validate_media_reference(
    client,
    media_id: UUID,
) -> None:
    response = (
        client
        .table("media_assets")
        .select("id")
        .eq("id", str(media_id))
        .maybe_single()
        .execute()
    )

    if not response.data:
        raise NotFoundError(
            "Media asset not found"
        )


def _validate_quiz_reference(
    client,
    article_id: UUID,
    quiz_id: UUID,
) -> None:
    response = (
        client
        .table("quizzes")
        .select("id")
        .eq("id", str(quiz_id))
        .eq("article_id", str(article_id))
        .maybe_single()
        .execute()
    )

    if not response.data:
        raise NotFoundError(
            "Quiz not found for this article"
        )


def _validate_opinion_reference(
    client,
    article_id: UUID,
    opinion_id: UUID,
) -> None:
    response = (
        client
        .table("opinion_questions")
        .select("id")
        .eq("id", str(opinion_id))
        .eq("article_id", str(article_id))
        .maybe_single()
        .execute()
    )

    if not response.data:
        raise NotFoundError(
            "Opinion question not found for this article"
        )


def _is_supported_media_reference(value: str | None) -> bool:
    if value is None:
        return False

    normalized = str(value).strip()
    if not normalized:
        return False

    if normalized.startswith("/") or normalized.startswith("media/"):
        return True

    parsed = urlparse(normalized)
    if parsed.scheme in {"http", "https"}:
        lower_path = parsed.path.lower()
        return lower_path.endswith((".mp3", ".wav", ".m4a", ".aac", ".ogg", ".oga", ".mp4", ".m4v", ".webm")) or "/audio/" in lower_path or "/media/" in lower_path

    return False


def _validate_block_payload(
    block_type: str,
    media_id: UUID | None,
    quiz_id: UUID | None,
    opinion_id: UUID | None,
    external_url,
    text_content: str | None,
    title: str | None,
) -> None:
    _validate_block_type(block_type)

    if block_type == "TEXT":
        if (
            media_id is not None
            or quiz_id is not None
            or opinion_id is not None
            or external_url is not None
        ):
            raise HTTPException(
                status_code=422,
                detail=(
                    "TEXT blocks cannot reference "
                    "media, quiz, opinion, or external_url"
                ),
            )

        if not text_content:
            raise HTTPException(
                status_code=422,
                detail="TEXT blocks require text_content",
            )

    elif block_type == "IMAGE":
        if media_id is None and external_url is None:
            raise HTTPException(
                status_code=422,
                detail="IMAGE blocks require media_id or external_url",
            )

        if (
            quiz_id is not None
            or opinion_id is not None
            or text_content is not None
        ):
            raise HTTPException(
                status_code=422,
                detail=(
                    "IMAGE blocks may only reference media_id or external_url "
                    "and optional caption"
                ),
            )

    elif block_type == "PODCAST":
        if quiz_id is not None or opinion_id is not None:
            raise HTTPException(
                status_code=422,
                detail=(
                    "PODCAST blocks cannot reference "
                    "quiz or opinion"
                ),
            )

        if media_id is None and not _is_supported_media_reference(str(external_url) if external_url is not None else None):
            raise HTTPException(
                status_code=422,
                detail="PODCAST blocks require a valid external_url or media_id",
            )

        if not text_content:
            raise HTTPException(
                status_code=422,
                detail="PODCAST blocks require text_content",
            )
        if not title or not title.strip():
            raise HTTPException(status_code=422, detail="PODCAST blocks require title")

    elif block_type == "QUIZ":
        if quiz_id is None:
            raise HTTPException(
                status_code=422,
                detail="QUIZ blocks require quiz_id",
            )

        if (
            media_id is not None
            or opinion_id is not None
            or external_url is not None
            or text_content is not None
        ):
            raise HTTPException(
                status_code=422,
                detail=(
                    "QUIZ blocks may only reference quiz_id"
                ),
            )

    elif block_type == "OPINION":
        if opinion_id is None:
            raise HTTPException(
                status_code=422,
                detail="OPINION blocks require opinion_id",
            )

        if (
            media_id is not None
            or quiz_id is not None
            or external_url is not None
            or text_content is not None
        ):
            raise HTTPException(
                status_code=422,
                detail=(
                    "OPINION blocks may only reference "
                    "opinion_id"
                ),
            )


def _validate_block_references(
    client,
    article_id: UUID,
    media_id: UUID | None,
    quiz_id: UUID | None,
    opinion_id: UUID | None,
) -> None:
    if media_id is not None:
        _validate_media_reference(
            client,
            media_id,
        )

    if quiz_id is not None:
        _validate_quiz_reference(
            client,
            article_id,
            quiz_id,
        )

    if opinion_id is not None:
        _validate_opinion_reference(
            client,
            article_id,
            opinion_id,
        )


# ============================================================
# ARTICLES — LIST
# ============================================================

@router.get(
    "/articles",
    response_model=list[SuperadminArticleListItem],
)
def list_articles(
    current_user: AuthContext = Depends(
        get_current_user
    ),
    article_status: str | None = Query(
        default=None,
        alias="status",
    ),
    category_id: UUID | None = None,
    search: str | None = Query(default=None, max_length=200),
):
    _require_superadmin(current_user)

    query = (
        current_user.client
        .table("articles")
        .select(ARTICLE_SELECT)
    )

    if article_status is not None:
        _validate_article_status(article_status)

        query = query.eq(
            "status",
            article_status,
        )

    if category_id is not None:
        query = query.eq(
            "category_id",
            str(category_id),
        )

    if search and search.strip():
        term = search.strip().replace(",", " ")
        query = query.or_(
            f"title.ilike.%{term}%,subtitle.ilike.%{term}%,author_name.ilike.%{term}%"
        )

    response = (
        query
        .order("created_at", desc=True)
        .execute()
    )

    return [
        _map_article(article)
        for article in (response.data or [])
    ]


# ============================================================
# ARTICLES — DETAIL
# ============================================================

@router.get(
    "/articles/{article_id}",
    response_model=SuperadminArticleDetailResponse,
)
def get_article(
    article_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    article = _get_article(
        current_user.client,
        article_id,
    )

    return _map_article(article)


# ============================================================
# ARTICLES — CREATE
# ============================================================

@router.post(
    "/articles",
    response_model=SuperadminArticleDetailResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_article(
    payload: SuperadminArticleCreate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    _get_category(
        current_user.client,
        payload.category_id,
    )

    _validate_article_type(
        payload.article_type
    )
    stored_type, featured_from_type = _normalize_article_type(payload.article_type)
    is_featured = payload.is_featured or featured_from_type
    slug = payload.slug.strip() if payload.slug else _slugify_title(payload.title)

    _validate_article_status(
        payload.status
    )

    if (
        payload.status == "SCHEDULED"
        and payload.scheduled_at is None
    ):
        raise HTTPException(
            status_code=422,
            detail=(
                "scheduled_at is required "
                "for scheduled articles"
            ),
        )

    try:
        article_response = (
            current_user.client
            .table("articles")
            .insert(
                {
                    "category_id": str(
                        payload.category_id
                    ),
                    "title": payload.title,
                    "subtitle": payload.subtitle,
                    "summary": payload.summary,
                    "slug": slug,
                    "article_type": stored_type,
                    "status": payload.status,
                    "cover_media_id": (
                        str(payload.cover_media_id)
                        if payload.cover_media_id
                        else None
                    ),
                    "cover_image_url": payload.cover_image_url,
                    "is_featured": is_featured,
                    "is_author_pick": payload.is_author_pick,
                    "author_name": payload.author_name,
                    "reading_time_minutes": payload.reading_time_minutes,
                    "created_by": str(
                        current_user.user.id
                    ),
                    "updated_by": str(
                        current_user.user.id
                    ),
                    "published_at": (
                        payload.published_at.isoformat()
                        if payload.published_at
                        else None
                    ),
                    "scheduled_at": (
                        _schedule_as_utc(payload.scheduled_at).isoformat()
                        if payload.scheduled_at
                        else None
                    ),
                }
            )
            .select(ARTICLE_SELECT)
            .execute()
        )
    except APIError as e:
        if getattr(e, "code", None) == "23505":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="An article with this slug already exists.",
            )
        raise

    article = extract_single_record(article_response.data, "Article creation failed")

    article_id = UUID(str(article["id"]))

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_CREATED",
        entity_type="ARTICLE",
        entity_id=article_id,
        metadata={
            "article_type": payload.article_type,
            "status": payload.status,
            "category_id": str(payload.category_id),
            "cover_media_id": (
                str(payload.cover_media_id)
                if payload.cover_media_id
                else None
            ),
        },
        client=current_user.client,
    )

    return _map_article(
        _get_article(
            current_user.client,
            article_id,
        )
    )
# ============================================================
# ARTICLE BLOCKS — REORDER
# IMPORTANT: Defined ABOVE any dynamic /{block_id} routes
# ============================================================

@router.patch(
    "/articles/{article_id}/blocks/reorder",
    response_model=list[SuperadminArticleBlockResponse],
)
def reorder_article_blocks(
    article_id: UUID,
    payload: SuperadminArticleBlockReorder,
    current_user: AuthContext = Depends(get_current_user),
):
    _require_superadmin(current_user)

    client = current_user.client

    _get_article(
        client,
        article_id,
    )

    if not payload.items:
        raise HTTPException(
            status_code=422,
            detail="At least one block is required",
        )

    block_ids = [item.block_id for item in payload.items]

    if len(block_ids) != len(set(block_ids)):
        raise HTTPException(
            status_code=422,
            detail="Duplicate block_id values are not allowed",
        )

    display_orders = [item.display_order for item in payload.items]

    if len(display_orders) != len(set(display_orders)):
        raise HTTPException(
            status_code=422,
            detail="Duplicate display_order values are not allowed",
        )

    existing_response = (
        client.table("article_blocks")
        .select("id, display_order")
        .eq("article_id", str(article_id))
        .execute()
    )

    existing_blocks = existing_response.data or []

    existing_ids = {
        UUID(str(block["id"]))
        for block in existing_blocks
        if isinstance(block, dict) and "id" in block
    }

    requested_ids = set(block_ids)

    if requested_ids != existing_ids:
        missing_ids = [str(i) for i in (existing_ids - requested_ids)]
        invalid_ids = [str(i) for i in (requested_ids - existing_ids)]

        detail_msg = "Reorder payload must contain every block belonging to the article exactly once."
        if missing_ids:
            detail_msg += f" Missing IDs: {missing_ids}"
        if invalid_ids:
            detail_msg += f" Invalid IDs: {invalid_ids}"

        raise HTTPException(
            status_code=422,
            detail=detail_msg,
        )

    # Move every block above the current range first. A fixed temporary range
    # can collide with values left behind by an interrupted reorder.
    current_orders = [
        int(block.get("display_order", 0))
        for block in existing_blocks
        if isinstance(block, dict)
    ]
    temporary_offset = max(current_orders, default=0) + len(payload.items) + 1

    for index, item in enumerate(payload.items):
        try:
            (
                client.table("article_blocks")
                .update({"display_order": temporary_offset + index})
                .eq("id", str(item.block_id))
                .eq("article_id", str(article_id))
                .execute()
            )
        except APIError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Unable to stage block reorder: {exc.message}",
            ) from exc

    # Step 2: Assign actual target display_order (e.g., 1, 2, 3)
    for item in payload.items:
        try:
            (
                client.table("article_blocks")
                .update({"display_order": item.display_order})
                .eq("id", str(item.block_id))
                .eq("article_id", str(article_id))
                .execute()
            )
        except APIError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Unable to apply block reorder: {exc.message}",
            ) from exc

    try:
        record_audit(
            actor_user_id=current_user.user.id,
            action="ARTICLE_BLOCKS_REORDERED",
            entity_type="ARTICLE",
            entity_id=article_id,
            metadata={
                "block_order": [
                    {
                        "block_id": str(item.block_id),
                        "display_order": item.display_order,
                    }
                    for item in payload.items
                ],
            },
            client=client,
        )
    except Exception:
        pass

    response = (
        client.table("article_blocks")
        .select(ARTICLE_BLOCK_SELECT)
        .eq("article_id", str(article_id))
        .order("display_order")
        .execute()
    )

    return [_map_block(block) for block in (response.data or [])]
# ============================================================
# ARTICLES — UPDATE
# ============================================================

@router.patch(
    "/articles/{article_id}",
    response_model=SuperadminArticleDetailResponse,
)
def update_article(
    article_id: UUID,
    payload: SuperadminArticleUpdate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    existing_article = _get_article(
        client,
        article_id,
    )

    updates = {}

    if payload.title is not None:
        updates["title"] = payload.title

    if payload.subtitle is not None:
        updates["subtitle"] = payload.subtitle

    if payload.summary is not None:
        updates["summary"] = payload.summary

    if payload.slug is not None:
        updates["slug"] = payload.slug

    if payload.category_id is not None:
        _get_category(
            client,
            payload.category_id,
        )

        updates["category_id"] = str(
            payload.category_id
        )

    if payload.article_type is not None:
        _validate_article_type(
            payload.article_type
        )
        stored_type, featured_from_type = _normalize_article_type(
            payload.article_type
        )
        updates["article_type"] = stored_type
        if payload.is_featured is None and featured_from_type:
            updates["is_featured"] = True

    if payload.cover_media_id is not None:
        updates["cover_media_id"] = str(
            payload.cover_media_id
        )

    if payload.cover_image_url is not None:
        updates["cover_image_url"] = payload.cover_image_url

    if payload.is_featured is not None:
        updates["is_featured"] = payload.is_featured

    if payload.is_author_pick is not None:
        updates["is_author_pick"] = payload.is_author_pick

    if payload.author_name is not None:
        updates["author_name"] = payload.author_name

    if payload.reading_time_minutes is not None:
        updates["reading_time_minutes"] = payload.reading_time_minutes

    if payload.published_at is not None:
        updates["published_at"] = (
            payload.published_at.isoformat()
        )

    if payload.scheduled_at is not None:
        updates["scheduled_at"] = (
            _schedule_as_utc(payload.scheduled_at).isoformat()
        )

    updates["updated_by"] = str(
        current_user.user.id
    )

    if updates:
        (
            client
            .table("articles")
            .update(updates)
            .eq("id", str(article_id))
            .execute()
        )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_UPDATED",
        entity_type="ARTICLE",
        entity_id=article_id,
        metadata={
            "article_fields": list(updates.keys()),
            "previous_status": existing_article.get(
                "status"
            ),
        },
        client=current_user.client,
    )

    return _map_article(
        _get_article(
            client,
            article_id,
        )
    )


# ============================================================
# ARTICLES — DELETE
# ============================================================

@router.delete(
    "/articles/{article_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_article(
    article_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    try:
        article = _get_article(
            client,
            article_id,
        )
    except NotFoundError:
        # DELETE is idempotent so stale CMS rows can be retried safely.
        return None

    (
        client
        .table("articles")
        .delete()
        .eq("id", str(article_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_DELETED",
        entity_type="ARTICLE",
        entity_id=article_id,
        metadata={
            "previous_status": article.get("status"),
            "category_id": article.get("category_id"),
        },
        client=current_user.client,
    )

    return None


# ============================================================
# ARTICLES — PUBLISH
# ============================================================

@router.post(
    "/articles/{article_id}/publish",
    response_model=SuperadminArticleDetailResponse,
)
def publish_article(
    article_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    article = _get_article(
        client,
        article_id,
    )

    (
        client
        .table("articles")
        .update(
            {
                "status": "PUBLISHED",
                "published_at": (
                    article.get("published_at")
                    or datetime.now(timezone.utc).isoformat()
                ),
                "scheduled_at": None,
                "updated_by": str(
                    current_user.user.id
                ),
            }
        )
        .eq("id", str(article_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_PUBLISHED",
        entity_type="ARTICLE",
        entity_id=article_id,
        metadata={
            "previous_status": article.get("status"),
        },
        client=current_user.client,
    )

    return _map_article(
        _get_article(
            client,
            article_id,
        )
    )


# ============================================================
# ARTICLES — UNPUBLISH
# ============================================================

@router.post(
    "/articles/{article_id}/unpublish",
    response_model=SuperadminArticleDetailResponse,
)
def unpublish_article(
    article_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    article = _get_article(
        client,
        article_id,
    )

    (
        client
        .table("articles")
        .update(
            {
                "status": "UNPUBLISHED",
                "scheduled_at": None,
                "updated_by": str(
                    current_user.user.id
                ),
            }
        )
        .eq("id", str(article_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_UNPUBLISHED",
        entity_type="ARTICLE",
        entity_id=article_id,
        metadata={
            "previous_status": article.get("status"),
        },
        client=current_user.client,
    )

    return _map_article(
        _get_article(
            client,
            article_id,
        )
    )


# ============================================================
# ARTICLES — SCHEDULE
# ============================================================

@router.post(
    "/articles/{article_id}/schedule",
    response_model=SuperadminArticleDetailResponse,
)
def schedule_article(
    article_id: UUID,
    payload: SuperadminArticleStatusUpdate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    if payload.scheduled_at is None:
        raise HTTPException(
            status_code=422,
            detail="scheduled_at is required",
        )

    client = current_user.client

    article = _get_article(
        client,
        article_id,
    )

    (
        client
        .table("articles")
        .update(
            {
                "status": "SCHEDULED",
                "scheduled_at": (
                    _schedule_as_utc(payload.scheduled_at).isoformat()
                ),
                "updated_by": str(
                    current_user.user.id
                ),
            }
        )
        .eq("id", str(article_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_SCHEDULED",
        entity_type="ARTICLE",
        entity_id=article_id,
        metadata={
            "previous_status": article.get("status"),
            "scheduled_at": (
                _schedule_as_utc(payload.scheduled_at).isoformat()
            ),
        },
        client=current_user.client,
    )

    return _map_article(
        _get_article(
            client,
            article_id,
        )
    )


# ============================================================
# ARTICLES — ARCHIVE
# ============================================================

@router.post(
    "/articles/{article_id}/archive",
    response_model=SuperadminArticleDetailResponse,
)
def archive_article(
    article_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    article = _get_article(
        client,
        article_id,
    )

    (
        client
        .table("articles")
        .update(
            {
                "status": "ARCHIVED",
                "scheduled_at": None,
                "updated_by": str(
                    current_user.user.id
                ),
            }
        )
        .eq("id", str(article_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_ARCHIVED",
        entity_type="ARTICLE",
        entity_id=article_id,
        metadata={
            "previous_status": article.get("status"),
        },
        client=current_user.client,
    )

    return _map_article(
        _get_article(
            client,
            article_id,
        )
    )


# ============================================================
# ARTICLES — AUTHOR'S PICKS
# ============================================================

@router.patch(
    "/articles/{article_id}/author-pick",
    response_model=SuperadminArticleDetailResponse,
)
def update_author_pick(
    article_id: UUID,
    payload: SuperadminAuthorPickUpdate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    article = _get_article(
        client,
        article_id,
    )

    if (
        payload.is_author_pick
        and payload.author_pick_order is None
    ):
        raise HTTPException(
            status_code=422,
            detail=(
                "author_pick_order is required "
                "when enabling Author's Pick"
            ),
        )

    (
        client
        .table("articles")
        .update(
            {
                "is_author_pick": (
                    payload.is_author_pick
                ),
                "author_pick_order": (
                    payload.author_pick_order
                    if payload.is_author_pick
                    else None
                ),
                "updated_by": str(
                    current_user.user.id
                ),
            }
        )
        .eq("id", str(article_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_AUTHOR_PICK_UPDATED",
        entity_type="ARTICLE",
        entity_id=article_id,
        metadata={
            "previous_is_author_pick": article.get(
                "is_author_pick",
                False,
            ),
            "previous_author_pick_order": article.get(
                "author_pick_order"
            ),
            "is_author_pick": payload.is_author_pick,
            "author_pick_order": (
                payload.author_pick_order
                if payload.is_author_pick
                else None
            ),
        },
    )

    return _map_article(
        _get_article(
            client,
            article_id,
        )
    )


# ============================================================
# ARTICLE BLOCKS — LIST
# ============================================================

@router.get(
    "/articles/{article_id}/blocks",
    response_model=list[SuperadminArticleBlockResponse],
)
def list_article_blocks(
    article_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    logger.info("Loading blocks for article %s", article_id)
    try:
        _require_superadmin(current_user)

        client = current_user.client
        _get_article(client, article_id)

        response = (
            client
            .table("article_blocks")
            .select(ARTICLE_BLOCK_SELECT)
            .eq("article_id", str(article_id))
            .order("display_order")
            .execute()
        )

        blocks = [_map_block(block) for block in (response.data or [])]
        logger.info("Loaded %d blocks for article %s", len(blocks), article_id)
        return blocks
    except Exception:
        logger.exception("Failed loading blocks for article %s", article_id)
        raise


# ============================================================
# ARTICLE BLOCKS — DETAIL
# ============================================================

@router.get(
    "/articles/{article_id}/blocks/{block_id}",
    response_model=SuperadminArticleBlockResponse,
)
def get_article_block(
    article_id: UUID,
    block_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    block = _get_article_block(
        current_user.client,
        article_id,
        block_id,
    )

    return _map_block(block)


# ============================================================
# ARTICLE BLOCKS — CREATE
# ============================================================

@router.post(
    "/articles/{article_id}/blocks",
    response_model=SuperadminArticleBlockResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_article_block(
    article_id: UUID,
    payload: SuperadminArticleBlockCreate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    display_order = (
        payload.display_order
        if payload.display_order is not None
        else payload.order_index
    )
    if display_order is None:
        raise HTTPException(status_code=422, detail="display_order is required")
    logger.info(
        "Creating article block article=%s type=%s order=%s media=%s quiz=%s opinion=%s external=%s text_length=%s",
        article_id,
        payload.block_type,
        display_order,
        payload.media_id,
        payload.quiz_id,
        payload.opinion_id,
        bool(payload.external_url),
        len(payload.text_content or ""),
    )
    _require_superadmin(current_user)

    client = current_user.client

    _get_article(
        client,
        article_id,
    )

    _validate_block_payload(
        block_type=payload.block_type,
        media_id=payload.media_id,
        quiz_id=payload.quiz_id,
        opinion_id=payload.opinion_id,
        external_url=payload.external_url,
        text_content=payload.text_content,
        title=payload.title,
    )

    _validate_block_references(
        client=client,
        article_id=article_id,
        media_id=payload.media_id,
        quiz_id=payload.quiz_id,
        opinion_id=payload.opinion_id,
    )

    # New blocks are normalized by the editor after they are created. If the
    # requested temporary order is already occupied, append this block above
    # the current range so the unique article/order constraint cannot reject
    # the save before the reorder step runs.
    occupied_response = (
        client.table("article_blocks")
        .select("id")
        .eq("article_id", str(article_id))
        .eq("display_order", display_order)
        .limit(1)
        .execute()
    )
    if occupied_response.data:
        highest_response = (
            client.table("article_blocks")
            .select("display_order")
            .eq("article_id", str(article_id))
            .order("display_order", desc=True)
            .limit(1)
            .execute()
        )
        highest_order = (
            int(highest_response.data[0].get("display_order", 0))
            if highest_response.data
            else 0
        )
        display_order = highest_order + 1

    block_response = (
        client
        .table("article_blocks")
        .insert(
            {
                "article_id": str(article_id),
                "block_type": payload.block_type,
                "display_order": display_order,
                "media_id": (
                    str(payload.media_id)
                    if payload.media_id
                    else None
                ),
                "quiz_id": (
                    str(payload.quiz_id)
                    if payload.quiz_id
                    else None
                ),
                "opinion_id": (
                    str(payload.opinion_id)
                    if payload.opinion_id
                    else None
                ),
                "external_url": (
                    str(payload.external_url)
                    if payload.external_url
                    else None
                ),
                "text_content": payload.text_content,
                "caption": payload.caption,
                "title": payload.title,
            }
        )
        .select(ARTICLE_BLOCK_SELECT)
        .execute()
    )

    block = extract_single_record(block_response.data, "Article block creation failed")
    block_id = UUID(str(block["id"]))

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_BLOCK_CREATED",
        entity_type="ARTICLE_BLOCK",
        entity_id=block_id,
        metadata={
            "article_id": str(article_id),
            "block_type": payload.block_type,
            "display_order": display_order,
            "media_id": (
                str(payload.media_id)
                if payload.media_id
                else None
            ),
            "quiz_id": (
                str(payload.quiz_id)
                if payload.quiz_id
                else None
            ),
            "opinion_id": (
                str(payload.opinion_id)
                if payload.opinion_id
                else None
            ),
            "external_url": (
                str(payload.external_url)
                if payload.external_url
                else None
            ),
        },
        client=current_user.client,
    )

    return _map_block(
        _get_article_block(
            client,
            article_id,
            block_id,
        )
    )


# ============================================================
# ARTICLE BLOCKS — UPDATE
# ============================================================

@router.patch(
    "/articles/{article_id}/blocks/{block_id}",
    response_model=SuperadminArticleBlockResponse,
)
def update_article_block(
    article_id: UUID,
    block_id: UUID,
    payload: SuperadminArticleBlockUpdate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    existing = _get_article_block(
        client,
        article_id,
        block_id,
    )

    block_type = existing["block_type"]

    media_id = (
        payload.media_id
        if payload.media_id is not None
        else existing.get("media_id")
    )

    quiz_id = (
        payload.quiz_id
        if payload.quiz_id is not None
        else existing.get("quiz_id")
    )

    opinion_id = (
        payload.opinion_id
        if payload.opinion_id is not None
        else existing.get("opinion_id")
    )

    external_url = (
        payload.external_url
        if payload.external_url is not None
        else existing.get("external_url")
    )

    text_content = (
        payload.text_content
        if payload.text_content is not None
        else existing.get("text_content")
    )

    caption = (
        payload.caption
        if payload.caption is not None
        else existing.get("caption")
    )

    _validate_block_payload(
        block_type=block_type,
        media_id=media_id,
        quiz_id=quiz_id,
        opinion_id=opinion_id,
        external_url=external_url,
        text_content=text_content,
        title=payload.title if payload.title is not None else existing.get("title"),
    )

    _validate_block_references(
        client=client,
        article_id=article_id,
        media_id=media_id,
        quiz_id=quiz_id,
        opinion_id=opinion_id,
    )

    block_updates = {}

    display_order = (
        payload.display_order
        if payload.display_order is not None
        else payload.order_index
    )

    if display_order is not None:
        block_updates["display_order"] = (
            display_order
        )

    if payload.media_id is not None:
        block_updates["media_id"] = str(
            payload.media_id
        )

    if payload.quiz_id is not None:
        block_updates["quiz_id"] = str(
            payload.quiz_id
        )

    if payload.opinion_id is not None:
        block_updates["opinion_id"] = str(
            payload.opinion_id
        )

    if payload.external_url is not None:
        block_updates["external_url"] = str(
            payload.external_url
        )

    if payload.text_content is not None:
        block_updates["text_content"] = payload.text_content

    if payload.caption is not None:
        block_updates["caption"] = payload.caption

    if payload.title is not None:
        block_updates["title"] = payload.title

    if block_updates:
        (
            client
            .table("article_blocks")
            .update(block_updates)
            .eq("id", str(block_id))
            .eq("article_id", str(article_id))
            .execute()
        )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_BLOCK_UPDATED",
        entity_type="ARTICLE_BLOCK",
        entity_id=block_id,
        metadata={
            "article_id": str(article_id),
            "block_type": block_type,
            "updated_fields": list(block_updates.keys()),
        },
        client=current_user.client,
    )

    return _map_block(
        _get_article_block(
            client,
            article_id,
            block_id,
        )
    )


# ============================================================
# ARTICLE BLOCKS — DELETE
# ============================================================

@router.delete(
    "/articles/{article_id}/blocks/{block_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_article_block(
    article_id: UUID,
    block_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    block = _get_article_block(
        client,
        article_id,
        block_id,
    )

    (
        client
        .table("article_blocks")
        .delete()
        .eq("id", str(block_id))
        .eq("article_id", str(article_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="ARTICLE_BLOCK_DELETED",
        entity_type="ARTICLE_BLOCK",
        entity_id=block_id,
        metadata={
            "article_id": str(article_id),
            "block_type": block.get("block_type"),
            "display_order": block.get("display_order"),
        },
        client=current_user.client,
    )

    return None



# ============================================================
# CATEGORIES — LIST
# ============================================================

@router.get(
    "/categories",
    response_model=list[SuperadminCategoryResponse],
)
def list_categories(
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    response = (
        current_user.client
        .table("categories")
        .select(CATEGORY_SELECT)
        .order("display_order")
        .execute()
    )

    categories = response.data or []
    for category in categories:
        article_count = (
            current_user.client.table("articles")
            .select("id", count="exact")
            .eq("category_id", str(category["id"]))
            .execute()
        )
        category["article_count"] = article_count.count or 0
    return categories


# ============================================================
# CATEGORIES — CREATE
# ============================================================

@router.post(
    "/categories",
    response_model=SuperadminCategoryResponse,
    status_code=status.HTTP_201_CREATED,
)
def create_category(
    payload: SuperadminCategoryCreate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    try:
        response = (
            current_user.client
            .table("categories")
            .insert(
                {
                    "name": payload.name.strip(),
                    "slug": payload.slug.strip(),
                    "description": payload.description,
                    "display_order": (
                        payload.display_order
                    ),
                    "is_active": payload.is_active,
                    "image_url": payload.image_url,
                }
            )
            .select(CATEGORY_SELECT)
            .execute()
        )
    except APIError as e:
        if getattr(e, "code", None) == "23505":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="A category with this name or slug already exists.",
            )
        raise

    category = extract_single_record(response.data, "Category creation failed")
    category_id = UUID(str(category["id"]))

    record_audit(
        actor_user_id=current_user.user.id,
        action="CATEGORY_CREATED",
        entity_type="CATEGORY",
        entity_id=category_id,
        metadata={
            "name": payload.name.strip(),
            "slug": payload.slug.strip(),
            "display_order": payload.display_order,
            "is_active": payload.is_active,
        },
        client=current_user.client,
    )

    return category


# ============================================================
# CATEGORIES — UPDATE
# ============================================================

@router.patch(
    "/categories/{category_id}",
    response_model=SuperadminCategoryResponse,
)
def update_category(
    category_id: UUID,
    payload: SuperadminCategoryUpdate,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    existing = _get_category(
        client,
        category_id,
    )

    updates = {}

    if payload.name is not None:
        updates["name"] = payload.name.strip()

    if payload.slug is not None:
        updates["slug"] = payload.slug.strip()

    if payload.description is not None:
        updates["description"] = (
            payload.description
        )

    if payload.display_order is not None:
        updates["display_order"] = (
            payload.display_order
        )

    if payload.is_active is not None:
        updates["is_active"] = payload.is_active

    if payload.image_url is not None:
        updates["image_url"] = payload.image_url

    if not updates:
        return existing

    try:
        response = (
            client
            .table("categories")
            .update(updates)
            .eq("id", str(category_id))
            .select(CATEGORY_SELECT)
            .execute()
        )
    except APIError as e:
        if getattr(e, "code", None) == "23505":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="A category with this name or slug already exists.",
            )
        raise

    category = extract_single_record(response.data, "Category update failed")

    record_audit(
        actor_user_id=current_user.user.id,
        action="CATEGORY_UPDATED",
        entity_type="CATEGORY",
        entity_id=category_id,
        metadata={
            "updated_fields": list(updates.keys()),
            "previous_values": {
                key: existing.get(key)
                for key in updates.keys()
            },
            "new_values": updates,
        },
        client=current_user.client,
    )

    return category


# ============================================================
# CATEGORIES — DELETE
# ============================================================

@router.delete(
    "/categories/{category_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
def delete_category(
    category_id: UUID,
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    category = _get_category(
        client,
        category_id,
    )

    # Categories are referenced by articles with an ON DELETE RESTRICT
    # constraint. Archive the category instead of orphaning or deleting its
    # articles; this keeps the CMS delete action safe and reversible.
    (
        client
        .table("categories")
        .update({"is_active": False})
        .eq("id", str(category_id))
        .execute()
    )

    record_audit(
        actor_user_id=current_user.user.id,
        action="CATEGORY_ARCHIVED",
        entity_type="CATEGORY",
        entity_id=category_id,
        metadata={
            "name": category.get("name"),
            "slug": category.get("slug"),
            "is_active": category.get("is_active"),
        },
        client=current_user.client,
    )

    return None


# ============================================================
# HOME MANAGEMENT
# ============================================================

@router.get(
    "/home",
    response_model=SuperadminHomeResponse,
)
def get_home_configuration(
    current_user: AuthContext = Depends(
        get_current_user
    ),
):
    _require_superadmin(current_user)

    client = current_user.client

    author_picks_response = (
        client
        .table("articles")
        .select(ARTICLE_SELECT)
        .eq("is_author_pick", True)
        .order("author_pick_order")
        .execute()
    )

    categories_response = (
        client
        .table("categories")
        .select(CATEGORY_SELECT)
        .eq("is_active", True)
        .order("display_order")
        .execute()
    )

    return {
        "author_picks": [
            _map_article(article)
            for article in (
                author_picks_response.data or []
            )
        ],
        "active_categories": (
            categories_response.data or []
        ),
    }