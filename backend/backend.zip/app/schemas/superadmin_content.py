from datetime import datetime
from uuid import UUID

from pydantic import BaseModel, Field, HttpUrl


# ============================================================
# COMMON
# ============================================================

class SuperadminCategoryResponse(BaseModel):
    id: UUID
    name: str
    slug: str
    description: str | None
    display_order: int
    is_active: bool
    created_at: datetime
    updated_at: datetime
    image_url: str | None = None
    article_count: int = 0


class SuperadminCategoryCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    slug: str = Field(min_length=1, max_length=200)
    description: str | None = Field(
        default=None,
        max_length=2000,
    )
    display_order: int = Field(
        default=0,
        ge=0,
    )
    is_active: bool = True
    image_url: str | None = None


class SuperadminCategoryUpdate(BaseModel):
    name: str | None = Field(
        default=None,
        min_length=1,
        max_length=200,
    )
    slug: str | None = Field(
        default=None,
        min_length=1,
        max_length=200,
    )
    description: str | None = Field(
        default=None,
        max_length=2000,
    )
    display_order: int | None = Field(
        default=None,
        ge=0,
    )
    is_active: bool | None = None
    image_url: str | None = None


# ============================================================
# ARTICLE
# ============================================================

class SuperadminArticleCreate(BaseModel):
    category_id: UUID
    title: str = Field(min_length=1, max_length=500)
    subtitle: str | None = Field(
        default=None,
        max_length=1000,
    )
    summary: str | None = Field(
        default=None,
        max_length=5000,
    )
    slug: str | None = Field(default=None, min_length=1, max_length=300)
    article_type: str = "STANDARD"
    status: str = "DRAFT"
    cover_media_id: UUID | None = None
    cover_image_url: str | None = None
    is_featured: bool = False
    is_author_pick: bool = False
    author_name: str | None = None
    reading_time_minutes: int | None = None
    published_at: datetime | None = None
    scheduled_at: datetime | None = None


class SuperadminArticleUpdate(BaseModel):
    category_id: UUID | None = None
    title: str | None = Field(default=None, min_length=1, max_length=500)
    subtitle: str | None = Field(default=None, max_length=1000)
    summary: str | None = Field(default=None, max_length=5000)
    slug: str | None = Field(default=None, min_length=1, max_length=300)
    article_type: str | None = None
    cover_media_id: UUID | None = None
    cover_image_url: str | None = None
    is_featured: bool | None = None
    is_author_pick: bool | None = None
    author_name: str | None = None
    reading_time_minutes: int | None = None
    published_at: datetime | None = None
    scheduled_at: datetime | None = None


class SuperadminArticleStatusUpdate(BaseModel):
    scheduled_at: datetime | None = None


class SuperadminAuthorPickUpdate(BaseModel):
    is_author_pick: bool
    author_pick_order: int | None = Field(
        default=None,
        ge=0,
    )


class SuperadminArticleListItem(BaseModel):
    id: UUID
    category_id: UUID
    title: str
    subtitle: str | None
    summary: str | None
    slug: str
    article_type: str
    status: str
    cover_media_id: UUID | None
    created_by: UUID | None
    updated_by: UUID | None
    created_at: datetime
    updated_at: datetime
    published_at: datetime | None
    scheduled_at: datetime | None

    is_author_pick: bool
    author_pick_order: int | None
    cover_image_url: str | None = None
    is_featured: bool = False
    author_name: str | None = None
    reading_time_minutes: int | None = None

    category: SuperadminCategoryResponse | None


class SuperadminArticleDetailResponse(
    SuperadminArticleListItem
):
    pass


# ============================================================
# HOME
# ============================================================

class SuperadminHomeResponse(BaseModel):
    author_picks: list[SuperadminArticleListItem]
    active_categories: list[SuperadminCategoryResponse]


# ============================================================
# ARTICLE BLOCKS
# ============================================================

class SuperadminArticleBlockResponse(BaseModel):
    id: UUID
    article_id: UUID
    block_type: str
    display_order: int
    media_id: UUID | None
    quiz_id: UUID | None
    opinion_id: UUID | None
    external_url: str | None
    text_content: str | None
    caption: str | None
    title: str | None = None
    media_url: str | None = None


class SuperadminArticleBlockCreate(BaseModel):
    block_type: str
    display_order: int | None = Field(
        default=None,
        ge=0,
    )
    order_index: int | None = Field(
        default=None,
        ge=0,
    )

    media_id: UUID | None = None
    quiz_id: UUID | None = None
    opinion_id: UUID | None = None

    external_url: str | None = None

    text_content: str | None = None
    caption: str | None = None
    title: str | None = None


class SuperadminArticleBlockUpdate(BaseModel):
    display_order: int | None = Field(
        default=None,
        ge=0,
    )
    order_index: int | None = Field(
        default=None,
        ge=0,
    )

    media_id: UUID | None = None
    quiz_id: UUID | None = None
    opinion_id: UUID | None = None

    external_url: str | None = None

    text_content: str | None = None
    caption: str | None = None
    title: str | None = None


class SuperadminArticleBlockReorderItem(BaseModel):
    block_id: UUID
    display_order: int = Field(
        ge=0,
    )


class SuperadminArticleBlockReorder(BaseModel):
    items: list[SuperadminArticleBlockReorderItem]